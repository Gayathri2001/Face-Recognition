function varargout = registerNewUser_0(varargin)
% REGISTERNEWUSER_0 M-file for registerNewUser_0.fig
%      REGISTERNEWUSER_0, by itself, creates a new REGISTERNEWUSER_0 or raises the existing
%      singleton*.
%
%      H = REGISTERNEWUSER_0 returns the handle to a new REGISTERNEWUSER_0 or the handle to
%      the existing singleton*.
%
%      REGISTERNEWUSER_0('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in REGISTERNEWUSER_0.M with the given input arguments.
%
%      REGISTERNEWUSER_0('Property','Value',...) creates a new REGISTERNEWUSER_0 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before registerNewUser_0_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to registerNewUser_0_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help registerNewUser_0

% Last Modified by GUIDE v2.5 09-Aug-2009 21:45:49

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @registerNewUser_0_OpeningFcn, ...
                   'gui_OutputFcn',  @registerNewUser_0_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before registerNewUser_0 is made visible.
function registerNewUser_0_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to registerNewUser_0 (see VARARGIN)

% Choose default command line output for registerNewUser_0
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

initialize_gui(hObject, handles, false);
% UIWAIT makes registerNewUser_0 wait for user response (see UIRESUME)
% uiwait(handles.figureRegisterNewUser);


% --- Outputs from this function are returned to the command line.
function varargout = registerNewUser_0_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function txtStartFile_Callback(hObject, eventdata, handles)
% hObject    handle to txtStartFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtStartFile as text
%        str2double(get(hObject,'String')) returns contents of txtStartFile as a double
startFile = str2double(get(hObject, 'String'));
if isnan(startFile)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
elseif isequal(startFile,0) && (startFile > handles.registerNewUser.FaceDataset.total ) 
    errordlg(['Input must be a greater than zero And input must be greater \n' ...
    'than already allocated records'],'Error');
end

% Save the new density value
handles.registerNewUser.startFile = startFile;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function txtStartFile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtStartFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtEndFile_Callback(hObject, eventdata, handles)
% hObject    handle to txtEndFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtEndFile as text
%        str2double(get(hObject,'String')) returns contents of txtEndFile as a double
endFile = str2double(get(hObject, 'String'));
if isnan(endFile)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
elseif isequal(endFile,0) && (endFile > handles.registerNewUser.FaceDataset.total ) ...
        && (endFile > get(handles.txtStartFile, 'Value'))
    errordlg(['Input must be a greater than zero And input must be greater \n' ...
    'than already allocated records'],'Error');
end

% Save the new density value
handles.registerNewUser.endFile = endFile;
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function txtEndFile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtEndFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtClassNo_Callback(hObject, eventdata, handles)
% hObject    handle to txtClassNo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtClassNo as text
%        str2double(get(hObject,'String')) returns contents of txtClassNo as a double
inputNo = str2double(get(hObject, 'String'));
if isnan(inputNo)
    set(hObject, 'String', 0);
    errordlg('inputNo must be a number','Error');
elseif isequal(inputNo,0) && (inputNo > handles.registerNewUser.FaceDataset.fields ) 
    errordlg(['Class ID must be a greater than zero And input must be greater \n' ...
    'than already allocated values'],'Error');
end

% Save the new density value
for i =1:inputNo
    if i < inputNo
        values(i) = 0;
    else
        values(i) = 1;
    end
end
handles.registerNewUser.values = values;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function txtClassNo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtClassNo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btnReset.
function btnReset_Callback(hObject, eventdata, handles)
% hObject    handle to btnReset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
initialize_gui(gcbf, handles, true);

% --- Executes on button press in btnExit.
function btnExit_Callback(hObject, eventdata, handles)
% hObject    handle to btnExit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg(['Close ' get(handles.figureRegisterNewUser,'Name') '?'],...
                     ['Close ' get(handles.figureRegisterNewUser,'Name') '...'],...
                     'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end
delete(handles.figureRegisterNewUser)

% --- Executes on button press in btnRegister.
function btnRegister_Callback(hObject, eventdata, handles)
% hObject    handle to btnRegister (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
massage =sprintf(['1. All the target records files will be updated, \n' ...
    '2. Previous training and testing recordsets will be deleted \n' ...
    '3. Neral network files would be deleted \n' ...
    '4. You must create new training and test records sets \n' ...
    '5. You must create new neural net \n' ...
    '6. You must retrain the neural net']);
titleMsg = 'Warning Deleting all the Previous records for updation';

selection = questdlg(massage, titleMsg, 'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end
delete(handles.figureRegisterNewUser)

writeTargets(handles.registerNewUser)

function initialize_gui(fig_handle, handles, isreset)
handles.registerNewUser.FaceDataset = FaceDatabase();
handles.registerNewUser.startFile = handles.registerNewUser.FaceDataset.total;
handles.registerNewUser.endFile = handles.registerNewUser.FaceDataset.total + 1;
handles.registerNewUser.values = handles.registerNewUser.FaceDataset.fields + 1;

set(handles.txtStartFile, 'String',  handles.registerNewUser.startFile);
set(handles.txtEndFile, 'String',  handles.registerNewUser.endFile);
set(handles.txtClassNo, 'String',  handles.registerNewUser.values);

guidata(handles.figureRegisterNewUser, handles);
