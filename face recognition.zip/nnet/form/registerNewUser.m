function varargout = registerNewUser(varargin)
% REGISTERNEWUSER M-file for registerNewUser.fig
%      REGISTERNEWUSER, by itself, creates a new REGISTERNEWUSER or raises the existing
%      singleton*.
%
%      H = REGISTERNEWUSER returns the handle to a new REGISTERNEWUSER or the handle to
%      the existing singleton*.
%
%      REGISTERNEWUSER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in REGISTERNEWUSER.M with the given input arguments.
%
%      REGISTERNEWUSER('Property','Value',...) creates a new REGISTERNEWUSER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before registerNewUser_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to registerNewUser_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help registerNewUser

% Last Modified by GUIDE v2.5 10-Aug-2009 21:47:11

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @registerNewUser_OpeningFcn, ...
                   'gui_OutputFcn',  @registerNewUser_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before registerNewUser is made visible.
function registerNewUser_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to registerNewUser (see VARARGIN)

% Choose default command line output for registerNewUser
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

initialize_gui(hObject, handles, false);
% UIWAIT makes registerNewUser wait for user response (see UIRESUME)
% uiwait(handles.figureRegisterNewUser);


% --- Outputs from this function are returned to the command line.
function varargout = registerNewUser_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

function txtClassNo_Callback(hObject, eventdata, handles)
% hObject    handle to txtClassNo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtClassNo as text
%        str2double(get(hObject,'String')) returns contents of txtClassNo as a double
IDStr = get(hObject, 'String');
if isnan(IDStr)
    set(hObject, 'String', 0);
    errordlg('IDStr must be a file number(s) or in pairs form or as a sequence of pairs','Error');
end

% Save the new IDStr value
ID = ['d' num2str(handles.registerNewUser.newID)];
IDStr = [ID '=[' IDStr '];'];
handles.registerNewUser.ID = ID;
handles.registerNewUser.IDStr = IDStr;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function txtClassNo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtClassNo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btnReset.
function btnReset_Callback(hObject, eventdata, handles)
% hObject    handle to btnReset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
initialize_gui(gcbf, handles, true);

% --- Executes on button press in btnExit.
function btnExit_Callback(hObject, eventdata, handles)
% hObject    handle to btnExit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg(['Close ' get(handles.figureRegisterNewUser,'Name') '?'],...
                     ['Close ' get(handles.figureRegisterNewUser,'Name') '...'],...
                     'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end
delete(handles.figureRegisterNewUser)

% --- Executes on button press in btnRegister.
function btnRegister_Callback(hObject, eventdata, handles)
% hObject    handle to btnRegister (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.uipanelMain, 'BackgroundColor', [1 0 0])
set(handles.text1, 'BackgroundColor', [1 0 0])
set(handles.text4, 'BackgroundColor', [1 0 0])
set(handles.txtClassNo, 'BackgroundColor', [1 0 0])
set(handles.btnReset, 'BackgroundColor', [1 0 0])
set(handles.btnExit, 'BackgroundColor', [1 0 0])
set(handles.btnRegister, 'BackgroundColor', [1 0 0])
set(handles.text6, 'BackgroundColor', [1 0 0])
set(handles.text7, 'BackgroundColor', [1 0 0])

massage =['{\fontsize{10}\color{red}1. All the target records files will be updated}, ' sprintf('\n ') ...
    '\fontsize{10}\color[rgb]{1 0 0}2. Previous training and testing recordsets will be deleted ' sprintf('\n ') ...
    '{\fontsize{18}\color{red}3. Neral network files would be deleted} ' sprintf('\n ') ...
    '4. You must create new training and test records sets ' sprintf('\n ') ...
    '5. You must create new neural net ' sprintf('\n ') ...
    '6. You must retrain the neural net' sprintf('\n ')];
titleMsg = 'Warning Deleting all the Previous records for updation';
options.Interpreter = 'tex';
options.Default = 'No';
selection = questdlg(massage, titleMsg, 'Yes','No', options);

if strcmp(selection,'No')
    set(handles.uipanelMain, 'BackgroundColor', [0.9255 0.9137 0.8471])
    set(handles.text1, 'BackgroundColor', [0.9255 0.9137 0.8471])
    set(handles.text4, 'BackgroundColor', [0.9255 0.9137 0.8471])
    set(handles.txtClassNo, 'BackgroundColor', [1 1 1])
    set(handles.btnReset, 'BackgroundColor', [0.9255 0.9137 0.8471])
    set(handles.btnExit, 'BackgroundColor', [0.9255 0.9137 0.8471])
    set(handles.btnRegister, 'BackgroundColor', [0.9255 0.9137 0.8471])
    set(handles.text6, 'BackgroundColor', [0.9255 0.9137 0.8471])
    set(handles.text7, 'BackgroundColor', [0.9255 0.9137 0.8471])
    return;
end

txtID = get(handles.txtClassNo, 'String');
if ~isnan(txtID)
%     updateAndRegister(handles.registerNewUser, 'true') % avtivate later
    set(handles.uipanelMain, 'BackgroundColor', [0.9255 0.9137 0.8471])
    set(handles.text1, 'BackgroundColor', [0.9255 0.9137 0.8471])
    set(handles.text4, 'BackgroundColor', [0.9255 0.9137 0.8471])
    set(handles.txtClassNo, 'BackgroundColor', [1 1 1])
    set(handles.btnReset, 'BackgroundColor', [0.9255 0.9137 0.8471])
    set(handles.btnExit, 'BackgroundColor', [0.9255 0.9137 0.8471])
    set(handles.btnRegister, 'BackgroundColor', [0.9255 0.9137 0.8471])
    set(handles.text6, 'BackgroundColor', [0.9255 0.9137 0.8471])
    set(handles.text7, 'BackgroundColor', [0.9255 0.9137 0.8471])
    msgbox('target files Updated', 'Updation completed')
else
    msgbox('Please enter the file number(s) first', 'error')
end
dialogMsg = ['{\fontsize{18}\color{red}Please remeber that neural net training takes 3 to 4 hours to train} ' sprintf('\n ') ...
    '{\fontsize{18}\color{red}on the current dataset on a fast system, i used 3GHz Dual core with 4Gb ram}' sprintf('\n ') ...
    '\fontsize{12}\color[rgb]{1 0.2 0.2}If you are sure than You must follow the following steps ' sprintf('\n ') ...
    '1 . The Previous Datasets and Neural network must also be deleted ' sprintf('\n ') ...
    '2. New Datasets must be created ' sprintf('\n ') ...
    '3. New Neural net must be created ' sprintf('\n ') ...
    '4. New Neural net must be trained'];
dialogTitle =  'Deletion of Datasets and neural network';
options.Interpreter = 'tex';
options.Default = 'Cancel';
selection = questdlg( dialogMsg, dialogTitle, ...
    'Delete','Backup Datasets & Neural net','Cancel', options);
if strcmp(selection,'cancel')
    return;
elseif strcmp(selection,'Delete')
    cd ..\code\MatlabNet\
    status = dos('del *.mat');
    if status
        msgbox('Failed to delete Neural net files', 'Deletion Failed')
    else
        msgbox('Deletion of neural net Completed', 'Deletion Completed')
    end
    cd ..\recordKeeping\
    status = dos('del *.mat');
    if status
        msgbox('Failed to delete Datasets', 'Deletion failed')
    else
        msgbox('Deletion of Datasets Completed', 'Deleted Completed')
    end 
elseif strcmp(selection,'Backup Datasets & Neural net')
    cd ..\code\MatlabNet\
    [status,result] = dos('copy *.mat .\Backup\');
    if status
        msgbox(result, 'Failed to Backup Neural net files')
    else
        msgbox(result, 'Backuped neural net Completed')
    end
    cd ..\recordKeeping\
    [status,result] = dos('copy *.mat .\Backup\');
    if status
        msgbox(result, 'Failed to Backup Datasets')
    else
        msgbox(result, 'Backuped Datasets Completed')
    end
end

function initialize_gui(fig_handle, handles, isreset)
cd(fileparts(mfilename('fullpath')))
handles.registerNewUser.FaceDataset = FaceDatabase();
handles.registerNewUser.total = handles.registerNewUser.FaceDataset.total;
handles.registerNewUser.newID = handles.registerNewUser.FaceDataset.fields + 1;

set(handles.txtClassNo, 'String', '');
guidata(handles.figureRegisterNewUser, handles);


% --- Executes on key press with focus on txtClassNo and none of its controls.
function txtClassNo_KeyPressFcn(hObject, eventdata, handles)
% hObject    handle to txtClassNo (see GCBO)
% eventdata  structure with the following fields (see UICONTROL)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over txtClassNo.
function txtClassNo_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to txtClassNo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on key press with focus on figureRegisterNewUser or any of its controls.
function figureRegisterNewUser_WindowKeyPressFcn(hObject, eventdata, handles)
% hObject    handle to figureRegisterNewUser (see GCBO)
% eventdata  structure with the following fields (see FIGURE)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)
