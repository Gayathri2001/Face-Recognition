clear all
a
a(1:10) = 1
a(11:20) = 2
a(21:30) = 3
a(31:40) = 4
a(41:50) = 5
a(51:60) = 6
a(61:70) = 7
a(71:80) = 8
a(81:90) = 9
a(91:100) = 10
plot9a)
plot(a)
plot(a,'--rs')
plot(a,'--rd')
plot(a,'--rX')
plot(a,'rX')
grid on
clear all
plot(a - 0.5 ,'rX')
a(1:10) = 1
a(11:20) = 2
a(21:30) = 3
a(31:40) = 4
a(41:50) = 5
a(51:60) = 6
a(61:70) = 7
a(71:80) = 8
a(81:90) = 9
a(91:100) = 10
plot(a - 0.5 ,'rX')
grid on
b = a
b
b(4) = 5
b(77) = 2
b(67) = 3
b(17) = 9
figure, plot(b - 0.5 ,'rX')
c= b- a
c= abs(b- a)
num(c)
num(c/c)
(c/c)
c
mapminmax(c)
mapminmax(c,[0 1])
positive(c)
c
c / c
c ./ c
c
c and c
c & c
c= abs( b-a)
d= c & c
e = b * d
e = b * double(d)
e = b * double(d')
e = b .* double(d')
e = b .* double(d)
plot(b - 0.5 ,'bX')
hold on
plot(e - 0.5 ,'rX')
grid on
e