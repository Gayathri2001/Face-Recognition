import java.awt.*;
import javax.swing.JFrame;

public class GUIMain 
{

    public GUIMain() 
    {
        JFrame frame;
        try
        {
            frame = new JFrame("test");
            frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
            Toolkit tk = Toolkit.getDefaultToolkit();
            Dimension dim = tk.getScreenSize();
            frame.setBounds(dim.width/2,dim.width/2,dim.height/2,dim.height/2);
            
            frame.setVisible(true);
        }
        catch(HeadlessException e) {}
    }
    
    public static void main(String args[]) 
    {
        GUIMain m = new GUIMain();
        System.out.println("i love you");
    }
    
}
