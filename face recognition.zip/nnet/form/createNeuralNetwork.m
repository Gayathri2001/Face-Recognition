function varargout = createNeuralNetwork(varargin)
% CREATENEURALNETWORK M-file for createNeuralNetwork.fig
%      CREATENEURALNETWORK, by itself, creates a new CREATENEURALNETWORK or raises the existing
%      singleton*.
%
%      H = CREATENEURALNETWORK returns the handle to a new CREATENEURALNETWORK or the handle to
%      the existing singleton*.
%
%      CREATENEURALNETWORK('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CREATENEURALNETWORK.M with the given input arguments.
%
%      CREATENEURALNETWORK('Property','Value',...) creates a new CREATENEURALNETWORK or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before createNeuralNetwork_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to createNeuralNetwork_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help createNeuralNetwork

% Last Modified by GUIDE v2.5 12-Aug-2009 19:57:14

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @createNeuralNetwork_OpeningFcn, ...
                   'gui_OutputFcn',  @createNeuralNetwork_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before createNeuralNetwork is made visible.
function createNeuralNetwork_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to createNeuralNetwork (see VARARGIN)

% Choose default command line output for createNeuralNetwork
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

initialize_gui(hObject, handles, false);

% UIWAIT makes createNeuralNetwork wait for user response (see UIRESUME)
% uiwait(handles.figureCreateNeuralNet);


% --- Outputs from this function are returned to the command line.
function varargout = createNeuralNetwork_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in popupmenuDataBase.
function popupmenuDatabase_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenuDataBase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenuDataBase contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenuDataBase
popup_sel_index = get(handles.popupmenuDatabase, 'Value');
switch popup_sel_index
    case 1
        handles.database = 'trainRec35.mat';
    case 2
        handles.database = 'trainRecSimulatedRecord.mat';
    case 3
        handles.database = 'trainReplicatedRecords.mat';
end
load(handles.database)
set(handles.lbInputs, 'String', size(p,2));
set(handles.lbOutputs, 'String', size(t,2));
set(handles.lbTotalRecords, 'String', size(p,1));
handles.createNeuralNetData.inputs = p;
handles.createNeuralNetData.NoOfOutputs = size(t,2);
popup_sel_index = get(handles.popupmenuDatabase, 'Value');
switch popup_sel_index
    case 1
        netName = 'net30+.mat';
    case 2
        netName = 'netSimulatedRecord.mat';
    case 3
        netName = 'netReplicatedRecords.mat';
end
handles.createNeuralNetData.netName = netName;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function popupmenuDatabase_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenuDataBase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
set(hObject, 'String', {'dabase35+', 'RecSimulatedRecords', 'ReplicatedRecords'});


function txtHidden_Callback(hObject, eventdata, handles)
% hObject    handle to txtHidden (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtHidden as text
%        str2double(get(hObject,'String')) returns contents of txtHidden as a double
hidden = str2double(get(hObject, 'String'));
if isnan(hidden)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new density value
handles.createNeuralNetData.hidden = hidden;
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function txtHidden_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtHidden (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtAlpha_Callback(hObject, eventdata, handles)
% hObject    handle to txtAlpha (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtAlpha as text
%        str2double(get(hObject,'String')) returns contents of txtAlpha as a double
alpha = str2double(get(hObject, 'String'));
if isnan(alpha)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new density value
handles.createNeuralNetData.alpha = alpha;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function txtAlpha_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtAlpha (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtMu_Callback(hObject, eventdata, handles)
% hObject    handle to txtMu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtMu as text
%        str2double(get(hObject,'String')) returns contents of txtMu as a double
mu = str2double(get(hObject, 'String'));
if isnan(mu)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new density value
handles.createNeuralNetData.mu = mu;
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function txtMu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtMu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtEpochs_Callback(hObject, eventdata, handles)
% hObject    handle to txtEpochs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtEpochs as text
%        str2double(get(hObject,'String')) returns contents of txtEpochs as a double
epochs = str2double(get(hObject, 'String'));
if isnan(epochs)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new density value
handles.createNeuralNetData.epochs = epochs;
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function txtEpochs_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtEpochs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtShow_Callback(hObject, eventdata, handles)
% hObject    handle to txtShow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtShow as text
%        str2double(get(hObject,'String')) returns contents of txtShow as a double
show = str2double(get(hObject, 'String'));
if isnan(show)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new density value
handles.createNeuralNetData.show = show;
guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function txtShow_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtShow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in btnBack.
function btnBack_Callback(hObject, eventdata, handles)
% hObject    handle to btnBack (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
delete(handles.figureCreateNeuralNet)
MainGUI();

% --- Executes on button press in btnCreate.
function btnCreate_Callback(hObject, eventdata, handles)
% hObject    handle to btnCreate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
popup_sel_index = get(handles.popupmenuTrainingFn, 'Value');
popup_string = get(handles.popupmenuTrainingFn, 'String');
switch popup_sel_index
    case 1
        handles.trainingFn = popup_string(1);
    case 2
        handles.trainingFn = popup_string(2);
    case 3
        handles.trainingFn = popup_string(3);
    case 4
        handles.trainingFn = popup_string(4);
    case 5
        handles.trainingFn = popup_string(5);
    case 6
        handles.trainingFn = popup_string(6);
    case 7
        handles.trainingFn = popup_string(7);
    case 8
        handles.trainingFn = popup_string(8);
end
h = handles.createNeuralNetData.hidden;
p = handles.createNeuralNetData.inputs;
m = handles.createNeuralNetData.NoOfOutputs;
trainingFn = handles.trainingFn;
net  = newff(minmax(p'),[h m],{'tansig','purelin'},char(trainingFn));
netName = handles.createNeuralNetData.netName;
cd([fileparts(mfilename('fullpath')) '.\..\code\MatlabNet\'])
if exist(netName,'file')
    msgbox('The network already exists')
    dialogMsg = ['\fontsize{18}\color{red}Please remeber that neural net training takes 3 to 4 hours to train ' sprintf('\n ') ...
    'on the current dataset on a fast system, ' sprintf('\n ') ...
    'I had used 3GHz Dual core system with 4Gb ram ' sprintf('\n ') ...
    'If you are sure, than You must follow the following steps ' sprintf('\n ') ...
    '1 . The Previous Neural network would be deleted ' sprintf('\n ') ...
    '2. You might have to create new training and test records sets ' sprintf('\n ') ...
    '3. You must retain the New Neural net'];
    dialogTitle =  'Deletion of neural network';
    selection = questdlg( dialogMsg, dialogTitle, ...
    'Delete','Backup Neural net and then save','cancel', 'cancel');
    if strcmp(selection,'cancel')
        return;
    elseif strcmp(selection,'Delete')
        status = dos('del *.mat');
        if status
            msgbox('Failed to delete Neural net files', 'Deletion Failed')
        else
            msgbox('Deletion of neural net Completed', 'Deletion Completed')
        end
    elseif strcmp(selection,'Backup Neural net and then save')
        [status,result] = dos('copy *.mat .\Backup\');
        if status
            msgbox(result, 'Failed to Backup Neural net files')
        else
            msgbox(result, 'Backuped neural net Completed')
        end
        save(netName,'net')
    end
elseif ~exist(netName,'file')
    massage =['\fontsize{18}\color{red} Would You like to save the newly created neural net ' sprintf('\n ') ];
    titleMsg = 'saving';
    options.Interpreter = 'tex';
    options.Default = 'No';
    selection = questdlg(massage, titleMsg, 'Yes','No', options);
    if strcmp(selection,'Yes')
        save(netName,'net')
        msgbox('Neural net saved')
    else
         return;
    end
end
guidata(hObject,handles)

% --- Executes on button press in btnReset.
function btnReset_Callback(hObject, eventdata, handles)
% hObject    handle to btnReset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
initialize_gui(gcbf, handles, true);
% --------------------------------------------------------------------
function initialize_gui(fig_handle, handles, isreset)
global p t inputByPerson targetByPerson
handles.createNeuralNetData.hidden = 16;
handles.createNeuralNetData.alpha  = 0.01;
handles.createNeuralNetData.mu     = 0;
handles.createNeuralNetData.epochs = 100;
handles.createNeuralNetData.show   = 10;
handles.createNeuralNetData.lock   = 0;

set(handles.txtHidden, 'String',  handles.createNeuralNetData.hidden);
set(handles.txtAlpha,  'String',  handles.createNeuralNetData.alpha);
set(handles.txtMu, 'String',      handles.createNeuralNetData.mu);
set(handles.txtEpochs,  'String', handles.createNeuralNetData.epochs);
set(handles.txtShow, 'String',    handles.createNeuralNetData.show);
set(handles.togglebuttonLock, 'Value', handles.createNeuralNetData.lock);
% set(handles.unitgroup, 'SelectedObject', handles.english);

set(handles.lbInputs, 'String', '');
set(handles.lbOutputs, 'String','');
set(handles.lbTotalRecords, 'String','');

% Update handles structure
guidata(handles.figureCreateNeuralNet, handles);





% --- Executes on selection change in popupmenuTrainingFn.
function popupmenuTrainingFn_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenuTrainingFn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenuTrainingFn contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenuTrainingFn


% --- Executes during object creation, after setting all properties.
function popupmenuTrainingFn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenuTrainingFn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
set(hObject, 'String', {'trainlm', 'traingd', 'traingdm', 'trainoss', 'trainr', 'trainrp', 'trainbfg', 'traincfg'});


% --- Executes during object creation, after setting all properties.
function figureCreateNeuralNet_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figureCreateNeuralNet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% --- Executes on button press in btnExit.
function btnExit_Callback(hObject, eventdata, handles)
% hObject    handle to btnExit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg(['Close ' get(handles.figureCreateNeuralNet,'Name') '?'],...
                     ['Close ' get(handles.figureCreateNeuralNet,'Name') '...'],...
                     'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end

delete(handles.figureCreateNeuralNet)


% --- Executes on button press in togglebuttonLock.
function togglebuttonLock_Callback(hObject, eventdata, handles)
% hObject    handle to togglebuttonLock (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of togglebuttonLock
if isequal(get(handles.togglebuttonLock, 'Value'), 1)
    set(handles.togglebuttonLock, 'Value', 0);   
    set(handles.togglebuttonLock, 'String', 'Unlock'); 
    set(handles.togglebuttonLock, 'TooltipString', 'Unlock the Neural net work file');
    cd(fileparts(mfilename('fullpath')))
    cd('..\code\MatlabNet')
    netName = handles.createNeuralNetData.netName;
    [status,res]= system(['cacls ' netName]);
    username = regexp(res,'\w+:[F|R]', 'match', 'once');
    username = username(1:end-2);
    [status, res] = system(['cacls ' netName '/e /p ' username ':f']);
    if status
        
    else
        
    end
else
    set(handles.togglebuttonLock, 'Value', 1);
    set(handles.togglebuttonLock, 'String', 'Locked'); 
    set(handles.togglebuttonLock, 'TooltipString', 'Once Locked the Neural net work file, it can''t be deleted or overwritten');
    cd(fileparts(mfilename('fullpath')))
    cd('..\code\MatlabNet')
    netName = handles.createNeuralNetData.netName;
    [status,res]= system(['cacls ' netName]);
    username = regexp(res,'\w+:[F|R]', 'match', 'once');
    username = username(1:end-2);
    system(['cacls ' netName '/e /p ' username ':r'])
end
