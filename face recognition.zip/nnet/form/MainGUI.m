function varargout = MainGUI(varargin)
% MAINGUI M-file for MainGUI.fig
%      MAINGUI, by itself, creates a new MAINGUI or raises the existing
%      singleton*.
%
%      H = MAINGUI returns the handle to a new MAINGUI or the handle to
%      the existing singleton*.
%
%      MAINGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAINGUI.M with the given input arguments.
%
%      MAINGUI('Property','Value',...) creates a new MAINGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MainGUI_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MainGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MainGUI

% Last Modified by GUIDE v2.5 10-Aug-2009 12:37:50

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MainGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @MainGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before MainGUI is made visible.
function MainGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MainGUI (see VARARGIN)

% Choose default command line output for MainGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

initialize_gui(hObject, handles, false);

% UIWAIT makes MainGUI wait for user response (see UIRESUME)
% uiwait(handles.figureGUIMain);


% --- Outputs from this function are returned to the command line.
function varargout = MainGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in btnTrain.
function btnTrain_Callback(hObject, eventdata, handles)
% hObject    handle to btnTrain (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
popup_sel_indexdb = get(handles.popupmenuDatabase, 'Value');
popup_string = get(handles.popupmenuDatabase, 'String');
switch popup_sel_indexdb
    case 1
        handles.MainGUIdata.database = char(popup_string(1));
    case 2
        handles.MainGUIdata.database = char(popup_string(2));
    case 3
        handles.MainGUIdata.database = char(popup_string(3));
    case 4
        handles.MainGUIdata.database = char(popup_string(4));
end
handles.MainGUIdata.selection = popup_sel_indexdb;
popup_sel_indexnet = get(handles.popupmenuNeuralNet, 'Value');
popup_string = get(handles.popupmenuNeuralNet, 'String');
switch popup_sel_indexnet
    case 1
        handles.MainGUIdata.netNames = char(popup_string);
    case 2
        handles.MainGUIdata.netNames = char(popup_string);
    case 3
        handles.MainGUIdata.netNames = char(popup_string);
    case 4
        handles.MainGUIdata.netNames = char(popup_string);
end
popup_sel_index = get(handles.popupmenuTrainingFn, 'Value');
popup_string = get(handles.popupmenuTrainingFn, 'String');
switch popup_sel_index
    case 1
        handles.MainGUIdata.trainingFn = char(popup_string(1));
    case 2
        handles.MainGUIdata.trainingFn = char(popup_string(2));
    case 3
        handles.MainGUIdata.trainingFn = char(popup_string(3));
    case 4
        handles.MainGUIdata.trainingFn = char(popup_string(4));
    case 5
        handles.MainGUIdata.trainingFn = char(popup_string(5));
    case 6
        handles.MainGUIdata.trainingFn = char(popup_string(6));
    case 7
        handles.MainGUIdata.trainingFn = char(popup_string(7));
    case 8
        handles.MainGUIdata.trainingFn = char(popup_string(8));
end
handles.MainGUIdata.trainingFnNo = popup_sel_index;
net = trBPM(handles.MainGUIdata);
handles.MainGUIdata.neuralNetwork = net;

% --- Executes on selection change in popupmenuDatabase.
function popupmenuDatabase_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenuDatabase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenuDatabase contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenuDatabase
set(handles.popupmenuNeuralNet, 'Interruptible', 'on')
popup_sel_index = get(handles.popupmenuDatabase, 'Value');
popup_db = get(handles.popupmenuDatabase, 'String');
set(handles.popupmenuNeuralNet, 'String', handles.MainGUIdata.netNames);
popup_net = get(handles.popupmenuNeuralNet, 'String');
switch popup_sel_index
    case 1
        handles.MainGUIdata.database  = popup_db(popup_sel_index);
        handles.MainGUIdata.netNames  = popup_net(popup_sel_index);
    case 2
        handles.MainGUIdata.database  = popup_db(popup_sel_index);
        handles.MainGUIdata.netNames  = popup_net(popup_sel_index);
    case 3
        handles.MainGUIdata.database  = popup_db(popup_sel_index);
        handles.MainGUIdata.netNames  = popup_net(popup_sel_index);
    case 4
        handles.MainGUIdata.database  = popup_db(popup_sel_index);
        handles.MainGUIdata.netNames  = popup_net(popup_sel_index);
end
set(handles.popupmenuNeuralNet, 'String', handles.MainGUIdata.netNames);
set(handles.popupmenuNeuralNet, 'Interruptible', 'off')


% --- Executes during object creation, after setting all properties.
function popupmenuDatabase_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenuDatabase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
cd([fileparts(mfilename('fullpath')) './../../'])
paths
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
mFiles = dir('.\nnet\code\recordKeeping\train*.mat');
if size(mFiles,1) < 1
    msgbox(sprintf(['There are no Recordset files available, \n' ...
        'please first create recordset files']),'No files available');
else
filesNames = cell(size(mFiles));
    for i=1:size(mFiles,1)
        filesNames(i) = {strrep(mFiles(i).name,'train','')};
    end
end
handles.MainGUIdata.dbNames = filesNames;
set(hObject, 'String', filesNames);
guidata(hObject,handles)

% --- Executes on selection change in popupmenuNeuralNet.
function popupmenuNeuralNet_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenuNeuralNet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenuNeuralNet contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenuNeuralNet


% --- Executes during object creation, after setting all properties.
function popupmenuNeuralNet_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenuNeuralNet (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
cd([fileparts(mfilename('fullpath')) './../../'])
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
mFiles = dir('.\nnet\code\MatlabNet\*.mat');
if size(mFiles,1) < 1
    msgbox(sprintf(['There are no Neural Network available, \n' ...
        'please first create Neural Network files']),'No files available');
else
filesNames = cell(size(mFiles));
    for i=1:size(mFiles,1)
        filesNames(i) = {mFiles(i).name};
    end
end
handles.MainGUIdata.netNames = filesNames;
set(hObject, 'String', filesNames);
guidata(hObject,handles)
% set(hObject, 'String', {'net30+', 'netSimulatedRecord', 'netReplicatedRecords'});

% --- Executes on button press in btnCreate.
function btnCreate_Callback(hObject, eventdata, handles)
% hObject    handle to btnCreate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
createNeuralNetwork();

% --- Executes on button press in btnTest.
function btnTest_Callback(hObject, eventdata, handles)
% hObject    handle to btnTest (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
popup_sel_indexdb = get(handles.popupmenuDatabase, 'Value');
popup_string = get(handles.popupmenuDatabase, 'String');
switch popup_sel_indexdb
    case 1
        handles.MainGUIdata.database = char(popup_string(1));
    case 2
        handles.MainGUIdata.database = char(popup_string(2));
    case 3
        handles.MainGUIdata.database = char(popup_string(3));
    case 4
        handles.MainGUIdata.database = char(popup_string(4));
end
handles.MainGUIdata.selection = popup_sel_indexdb;
popup_sel_indexnet = get(handles.popupmenuNeuralNet, 'Value');
popup_string = get(handles.popupmenuNeuralNet, 'String');
switch popup_sel_indexnet
    case 1
        handles.MainGUIdata.netNames = char(popup_string);
    case 2
        handles.MainGUIdata.netNames = char(popup_string);
    case 3
        handles.MainGUIdata.netNames = char(popup_string);
    case 4
        handles.MainGUIdata.netNames = char(popup_string);
end
popup_sel_index = get(handles.popupmenuTrainingFn, 'Value');
popup_string = get(handles.popupmenuTrainingFn, 'String');
switch popup_sel_index
    case 1
        handles.MainGUIdata.trainingFn = char(popup_string(1));
    case 2
        handles.MainGUIdata.trainingFn = char(popup_string(2));
    case 3
        handles.MainGUIdata.trainingFn = char(popup_string(3));
    case 4
        handles.MainGUIdata.trainingFn = char(popup_string(4));
    case 5
        handles.MainGUIdata.trainingFn = char(popup_string(5));
    case 6
        handles.MainGUIdata.trainingFn = char(popup_string(6));
    case 7
        handles.MainGUIdata.trainingFn = char(popup_string(7));
    case 8
        handles.MainGUIdata.trainingFn = char(popup_string(8));
end
handles.MainGUIdata.trainingFnNo = popup_sel_index;
net = tsBPM(handles.MainGUIdata);


% --- Executes on button press in btnHelp.
function btnHelp_Callback(hObject, eventdata, handles)
% hObject    handle to btnHelp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
HelpGUI();

% --- Executes on button press in btnExit.
function btnExit_Callback(hObject, eventdata, handles)
% hObject    handle to btnExit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg(['Close ' get(handles.figureGUIMain,'Name') '?'],...
                     ['Close ' get(handles.figureGUIMain,'Name') '...'],...
                     'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end

delete(handles.figureGUIMain)
% --------------------------------------------------------------------
function initialize_gui(fig_handle, handles, isreset)
cd([fileparts(mfilename('fullpath')) './../../'])
paths
handles.MainGUIdata.epochs = 100;
handles.MainGUIdata.alpha  = 0.05;
handles.MainGUIdata.show   = 10;
handles.MainGUIdata.ValidTest = 2;
set(handles.txtEpochs, 'String', handles.MainGUIdata.epochs);
set(handles.txtAlpha,  'String', handles.MainGUIdata.alpha);
set(handles.txtShow,  'String', handles.MainGUIdata.show);
% set(handles.GroupBtn,  'String', handles.MainGUIdata.show);
% 
% Update handles structure
guidata(handles.figureGUIMain, handles);

% --------------------------------------------------------------------
function FileMenu_Callback(hObject, eventdata, handles)
% hObject    handle to FileMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function OpenMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to OpenMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
file = uigetfile('*.fig');
if ~isequal(file, 0)
    open(file);
end

% --------------------------------------------------------------------
function PrintMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to PrintMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
printdlg(handles.figureGUIMain)

% --------------------------------------------------------------------
function CloseMenuItem_Callback(hObject, eventdata, handles)
% hObject    handle to CloseMenuItem (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
selection = questdlg(['Close ' get(handles.figureGUIMain,'Name') '?'],...
                     ['Close ' get(handles.figureGUIMain,'Name') '...'],...
                     'Yes','No','Yes');
if strcmp(selection,'No')
    return;
end

delete(handles.figureGUIMain)





function txtEpochs_Callback(hObject, eventdata, handles)
% hObject    handle to txtEpochs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtEpochs as text
%        str2double(get(hObject,'String')) returns contents of txtEpochs as a double
epochs = str2double(get(hObject, 'String'));
if isnan(epochs)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new density value
handles.MainGUIdata.epochs = epochs;
guidata(hObject,handles)



% --- Executes during object creation, after setting all properties.
function txtEpochs_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtEpochs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtAlpha_Callback(hObject, eventdata, handles)
% hObject    handle to txtAlpha (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtAlpha as text
%        str2double(get(hObject,'String')) returns contents of txtAlpha as a double
alpha = str2double(get(hObject, 'String'));
if isnan(alpha)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new density value
handles.MainGUIdata.alpha = alpha;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function txtAlpha_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtAlpha (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function txtShow_Callback(hObject, eventdata, handles)
% hObject    handle to txtShow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of txtShow as text
%        str2double(get(hObject,'String')) returns contents of txtShow as a double
show = str2double(get(hObject, 'String'));
if isnan(show)
    set(hObject, 'String', 0);
    errordlg('Input must be a number','Error');
end

% Save the new density value
handles.MainGUIdata.show = show;
guidata(hObject,handles)

% --- Executes during object creation, after setting all properties.
function txtShow_CreateFcn(hObject, eventdata, handles)
% hObject    handle to txtShow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenuTrainingFn.
function popupmenuTrainingFn_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenuTrainingFn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenuTrainingFn contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenuTrainingFn


% --- Executes during object creation, after setting all properties.
function popupmenuTrainingFn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenuTrainingFn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
set(hObject, 'String', {'trainlm', 'traingd', 'traingdm', 'trainoss', 'trainr', 'trainrp', 'trainbfg', 'traincfg'});


% --- Executes on button press in btnReset.
function btnReset_Callback(hObject, eventdata, handles)
% hObject    handle to btnReset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
initialize_gui(gcbf, handles, true);
set(handles.popupmenuNeuralNet, 'Interruptible', 'on')


% --- Executes when selected object is changed in GroupBtn.
function GroupBtn_SelectionChangeFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in GroupBtn 
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if (hObject == handles.radiobuttonValidation)
    handles.MainGUIdata.ValidTest = 1;
else
    handles.MainGUIdata.ValidTest = 2;
end



% --- Executes on button press in btnSave.
function btnSave_Callback(hObject, eventdata, handles)
% hObject    handle to btnSave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if exist(char(get(handles.popupmenuNeuralNet, 'String')),'file')
    dialogMsg = '{\fontsize{18}\color{red}The network already exists, You want to overwrite it } ';
    dialogTitle =  'Overwrite the neural network';
    options.Interpreter = 'tex';
    options.Default = 'Cancel';
    selection = questdlg( dialogMsg, dialogTitle, 'Overwrite', 'Cancel', options);
    if strcmp(selection,'Cancel')
        return;
    else
        if isfield(handles.MainGUIdata, 'neuralNetwork')
            save(handles.MainGUIdata.neuralNetwork,'net')
        else
            msgbox('First train the neural network to create it and then save it')
        end
    end
elseif get(handles.togglebuttonLock, 'Value')
    if isfield(handles.MainGUIdata, 'neuralNetwork')
        save(handles.MainGUIdata.neuralNetwork,'net')
    else
        msgbox('First train the neural network to create it and then save it')
    end
else
    msgbox('Please manually unlock the network file')
end



% --- Executes on button press in radiobuttonLock.
function radiobuttonLock_Callback(hObject, eventdata, handles)
% hObject    handle to radiobuttonLock (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobuttonLock
cd(fileparts(mfilename('fullpath')))
cd('..\code\MatlabNet')
netName = handles.MainGUIdata.netNames; %popupmenuNeuralNet
[status,res]= system(['cacls ' netName]);
username = regexp(res,'\w+:[F|R]', 'match', 'once');
username = username(1:end-2);
system(['cacls ' netName '/e /p ' username ':r'])



% --- Executes on button press in btnNewDatasets.
function btnNewDatasets_Callback(hObject, eventdata, handles)
% hObject    handle to btnNewDatasets (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
createNewDataset();

% --- Executes on button press in btnRegisterNewUser.
function btnRegisterNewUser_Callback(hObject, eventdata, handles)
% hObject    handle to btnRegisterNewUser (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
registerNewUser();
