function x1 = getFileData(InputFile)
fid = fopen(InputFile,'r');
i = 1;
while 1
    tline = fgetl(fid);
    if ~ischar(tline),   break,   end
    %disp(tline)
    if( i ==2)
        [A,B,C,D] = strread(tline);
        x1 = [A,B,C,D];
    end
    i = i+1;
end
fclose(fid);
