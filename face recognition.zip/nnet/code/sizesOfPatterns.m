clc
sprintf(' size(d1,2) %5d\n size(d2,2) %5d\n size(d3,2) %5d\n size(d4,2) %5d\n size(d5,2) %5d\n size(d6,2) %5d\n size(d7,2) %5d\n size(d8,2) %5d\n size(d9,2) %5d\n size(d10,2) %5d\n size(d11,2) %5d\n size(d12,2) %5d\n size(d13,2) %5d\n size(d14,2) %5d\n size(d15,2) %5d\n size(d16,2) %5d\n size(d17,2) %5d\n size(d18,2) %5d\n size(d19,2) %5d\n size(d20,2) %5d\n size(d21,2) %5d\n size(d22,2) %5d\n size(d23,2) %5d\n', ...
        size(d1,2) ,size(d2,2) ,size(d3,2) ,size(d4,2), ...
        size(d5,2) ,size(d6,2) ,size(d7,2) ,size(d8,2), ...
        size(d9,2) ,size(d10,2) ,size(d11,2) ,size(d12,2), ...
        size(d13,2) ,size(d14,2) ,size(d15,2) ,size(d16,2), ...
        size(d17,2) ,size(d18,2) ,size(d19,2) ,size(d20,2), ...
        size(d21,2) ,size(d22,2) ,size(d23,2))
szf = [
1 121
 2  58
 3  59
 4   2
 5  78
 6  88
 7 100
 8  90
 9  61
 10  71
 11 106
 12  99
 13 150
 14  94
 15  51
 16  35
 17  40
 18  40
 19   6
 20  46
 21  51
 22  25
 23  50
 ];