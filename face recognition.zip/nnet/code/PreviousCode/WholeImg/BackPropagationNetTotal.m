function [v,v0,w,w0] = BackPropagationNet(InputFile,TargetFile)
%Create an back propagation net
% x     Input training vector:
%    x = (x1, ..... xi, ..... xn)
% t     Output training vector:
%    t = (t1, ..... tk, ..... tm)
% sigmak Portion of error correction weight adjustment for wjk that is due
% to an error at the output unit Yk; also, the information about the error
% at unit Yk that is propagated back to the hidden units that feed into
% unit Yk
% sigmaj Portion of error correction weight adjustment for vij that is due
%to the backpropagation of error information from the output layer to the
%hidden unit Zj.
% alpha Learning rate
% Xi Input unit i:
%    For an input unit; the input signal and output signal are the same,
%    namely, xi.
% v0j Bais on the hidden unit j.
% Zj Hidden init j:
% The net input to Zj is denoted z_inj:
%   z_inj = v0j + sum(xi*vij).
%    The output signal (activation) of Zj is denoted zj:
%   zj = f(z_inj).
% w0k Bais on output unit k.
% Yk Output unit k.
% The net input to Yk is denoted y_ink:
%    y_ink = w0k + sum(zj*wjk)
%   the output signal (activation) of Yk is denoted yk:
%  yk = f(y_ink).
% Activation function:
% f(x) = 2/(1 + exp(-x)) -1
% with its derivative 
% f'(x) = 1/2*(1 + f(x))*(1-f(x))

%% Opening of the Input / Target Files
disp('Loading the input vector x and target vectors')
if nargin < 1
    EnvPath = getResPathsFrmEnvVar();
    EnvPath = EnvPath(1,:);
    cd([strtrim(EnvPath) '\Database\Face Database\BioID-FaceDatabase-V1.2\']);
%    BioID_0000.eye            BioID_0000.pgm
    for var=1:1  %1520
        InputFile = sprintf('BioID_%04d.pgm', var); %pgm
        TargetFile = sprintf('BioID_%04d.pgm', var);
%        disp(InputFile)
    end
end
%x1 = importdata(InputFile); t1 = importdata(TargetFile); 
%x1 = getFileData(InputFile); t1 = getFileData(TargetFile);
%x1 = round(rand(100,7));  %x(:,:)        % t1 = x1;  %t(:,:)
x1 = imread(InputFile);
t1 = imread(TargetFile);
% disp('Input vector') ,disp(x1)
% disp('Target vector'), disp(t1)

%% Enter the Architecture detail
disp('Enter the Architecture detail');
%n = input('Enter the no of input units');
%p = input('Enter the no of hidden units');
%m = input('Enter the no of output units');
si =round((850*1024*1024)/13);
n = size(x1(:),1);
m = n;
p = round(si/(size(x1(:),1)));
% Tp = input('Enter the no of Training vectors');
Tp = 1;
alpha = input('Enter the Learning rate');
%% Preprocess the data
%[in,out,pf, tf] = imgHistGrayResizeMap(filename);

%% step 0 Initialization
disp('weights v and w are getting initialised randomly');
    v1 = -0.5+(0.5-(-0.5))*int8(ones(n,p));  %rand(n,p);
    w  = -0.5+(0.5-(-0.5))*int8(zeros(p,m)); %rand(p,m);
    
    f = 0.7 *((p)^(1/n));
    v0 = -f+(f+f)*rand(1,p);
    w0 = -0.5+(0.5-(-0.5))*rand(1,m);

for i = 1:n
    for j=1:p
        v(i,j) = (f * v1(i,j))/(norm(v1(:,j)));
    end
end
%for T = 1:Tp
%    for i=1:n
%        x(T,i) = x1(T,i);
%    end

%    for i=1:m
%        t(T,i) = t1(T,i);
%    end
%end
x = x1(:);  %x(:,:)
t = t1(:);  %t(:,:)
chw = zeros(p,m);
chw0 = zeros(1,m);
chv = zeros(n,p);
chv0 = zeros(1,p);
dk = zeros(Tp,m);
yin = zeros(Tp,m);
y = zeros(Tp,m);
zin = zeros(Tp,p);
dinj = zeros(Tp,p);
dj =  zeros(Tp,p);
z =  zeros(Tp,p);
iteration =0;
er = 0;
%% step 1 While stoping condition is false do step 2 -9
while er==0 % do Step 2-9
    disp('Epoch number is')
    disp(iteration)
    totalerr = 0;
% Step 2 For each Training pair, od Steps 3-8
    for IP = 1:Tp:size(x1,1) % IP is the steps (Tp) in inputs of X1
        for T=1:Tp % For loop Step 2
            for j =1:p
                zin(T,j) = v0(j) + sum(x(T,:) .* v(:,j)');
                z(T,j) = ((2/(1+exp(-zin(T,j))))-1);
            end

            for j =1:m
                yin(T,j) = w0(j) + sum(z(T,:) .* w(:,j)');
                y(T,j) = ((2/(1+exp(-yin(T,j))))-1);
                totalerr = 0.5 * ((t(T,j) - y(T,j))^2)+totalerr;
            end

            for k =1:m
                dk(T,k) = (t(T,k) - y(T,k))*((1/2)*(1+y(T,k))*(1 - y(T,k)));
            end
            for j =1:p
                chw(j,:) = alpha * dk(T,:) * z(T,j);
            end
            chw0(:) = alpha * dk(T,:);

            for j=1:p
                dinj(T,j) = sum(dk(T,:) .* w(j,:));
                dj(T,j) = (dinj(T,j) * ((1/2) * (1 + z(T,j))* (1 - z(T,j))));
            end
            for j =1:p
                chv(:,j) = alpha * dj(T,j) * x(T,:);
    %                chv(j,:) = alpha * dj(T,:) * x(T,j);
            end
            chv0(:) = alpha * dj(T,:);            
    %            chv0(:) = aplha * dj(T,:);

            v(1:n,1:p) = v(1:n,1:p) + chv(1:n, 1:p);
            v0(1:p)    = v0(1:p) + chv0(1:p);
            w(1:p,1:m) = w(1:p,1:m) + chw(1:p, 1:m);
            w0(1:m)    = w0(1:m) + chw0(1:m);

        end % End of for loop Step 2
    end
disp('value of y at this iteration');
disp(y)
error = sqrt((t-y).^2);
if max(max(error)) < 0.05
    er =1;
else
    er = 0;
end
iteration = iteration +1;
finerr = totalerr/(Tp*7);
disp(finerr)

if finerr < 0.01
    er = 1;
else
    er = 0;
end
end %% End of wile loop Step 1
end %% End of Function / File