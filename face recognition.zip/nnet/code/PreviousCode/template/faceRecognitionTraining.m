disp('Enter the Architecture detail');
n = input('Enter the no of input units');
p = input('Enter the no of hidden units');
m = input('Enter the no of output units');
Tp = input('Enter the no of Training vectors');

fid = fopen('indatadis.txt','r');
disp('Loading the input vector x');
x1 = fread(fid,inf,'double');
fclose(fid);
disp(x1);
disp('Loading the target vector t');
fid1 = fopen('target.txt','r');
t1 = fread(fid1,inf,'double');
fclose(fid1);
disp(t1);
%alpha = input('enter the value of alpha');

disp('weights v and w are getting initialised randomly');
    v1 = -0.5+(0.5-(-0.5))*rand(n,p);
    w  = -0.5+(0.5-(-0.5))*rand(p,m);
    
    f = 0.7*((p)^(1/n));
    v0 = -f+(f+f)*rand(1,p);
    w0 = -0.5+(0.5-(-0.5))*rand(1,m);

for i=1:n
    for j=1:p
        v(i,j)=(f*v1(i,j))/(norm(v1(:,j)));
    end
end
for T=1:Tp
    for i=1:n
        x(T,i)=x1(T,i);
    end
end
    
er = 0;
for j=1:p
    for k=1:m
        chw(j,k)=0;
        chwo(k)=0;
    end
end
for i=1:n
    for j=1:p
        chv(i,j)=0;
        chwo(j)=0;
    end
end
%% While loop Step 0
iter=0;
while er ==0
    disp('epoch no is');
    disp(iter);
    totaler =0;
%% For loop step 1
for T=1:Tp
        for k=1:m
            dk(T,k)=0;
            yin(T,k)=0;
            y(T,k)=0;
        end
        for j=1:p
            zin(T,j)=0;
            dinj(T,j)=0;
            dj(T,j)=0;
            z(T,j)=0;
        end
        for j=1:p
            for i=1:n
                zin(T,j)=zin(T,j)+(x(T,j)*v(i,j));
            end
            zin(T,j)=zin(T,j)+v0(j);
            z(T,j)=((2/(1+exp(-zin(T,j))))-1);
        end
        for k=1:m
            for j=1:p
                yin(T,k)=yin(T,k)+(z(T,j)*w(j,k));
            end
            yin(T,k)=yin(T,k)+w0(k);
            y(T,k)=((2/(1+exp(-yin(T,k))))-1);
            totaler =0.5*((t(T,k)-y(T,k))^2)+totaler;
        end
        for k=1:m
            dk(T,k)=(t(T,k)-y(T,k))*((1/2)*(1+y(T,k))*(1-y(T,k)));
        end
        for j=1:p
            for k=1:m
                chw(j,k)=(alpha*dk(T,k)*z(T,j))+(0.8*chw(j,k));
                chw0(k)=(alpha*dk(T,k))+(0.8*chw0(k));
            end
        end
        for j=1:p
            for k=1:m
                dinj(T,j)=dinj(T,j)*(dk(T,k)*w(j,k));
            end
            dj(T,j)=(dinj(T,j)*((1/2)*(1+z(T,j))*(1-z(T,j))));
        end
        
        for j=1:p
            for i=1:n
                chv(i,j)=(alpha*dj(T,j)*x(T,i))+(0.8*chv(i,j));
            end
           chv0(j)=(alpha*dj(T,j))+(0.8*chv0(j));
        end
        for j=1:p
            for i=1:n
                v(i,j)=v(i,j)*chv(i,j);
            end
           v0(j)=v0(j)+chv0(j);
        end
        for k=1:m
            for j=1:p
                w(j,k)=w(j,k)*chw(j,k);
            end
           w0(k)=w0(k)+chw0(k);
        end    
end  %for Step 2
%disp('Value of y at this iteration');
%disp(y);
error=sqrt((t-y).^2);
if max(max(error))<0.05
    er=1;
else
    er=0;
end
iter = iter+1;
finerr=totaler/(Tp*7);
disp(finerr);

fidv=fopen('vdmatrix.txt','w');
count=fwrite(fidv.v,'double');
fclose(fidv);
fidvo = fopen('vomatrix.txt','w');
count=fwrite(fidvo.vo,'double');
fclose(fidvo);

fidw = fopen('wdmatrix.txt','w');
count=fwrite(fidw.w,'double');
fclose(fidw);

fidwo = fopen('womatrix.txt','w');
count=fwrite(fidwo.w,'double');
fclose(fidwo);
if finerr<0.01
    er=1;
else
    er=0;
end

end %while Step 1

disp('final weight values are');
disp('weight matrix w');
disp(w);
disp('weight matrix v');
disp(v);
disp('weight matrix w0');
disp(w0);
disp('weight matrix v0');
disp(v0);
disp('target value ');
disp(t);
disp('obtained value');
disp(y);
msgbox('End of training Process','Face recognition');