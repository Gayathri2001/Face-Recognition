function [v,v0,w,w0, mov] = trainingBackPropagationNet(v,v0,w,w0)
%Create an back propagation net
% x     Input training vector:
%    x = (x1, ..... xi, ..... xn)
% t     Output training vector:
%    t = (t1, ..... tk, ..... tm)
% sigmak Portion of error correction weight adjustment for wjk that is due
% to an error at the output unit Yk; also, the information about the error
% at unit Yk that is propagated back to the hidden units that feed into
% unit Yk
% sigmaj Portion of error correction weight adjustment for vij that is due
%to the backpropagation of error information from the output layer to the
%hidden unit Zj.
% alpha Learning rate
% Xi Input unit i:
%    For an input unit; the input signal and output signal are the same,
%    namely, xi.
% v0j Bais on the hidden unit j.
% Zj Hidden init j:
% The net input to Zj is denoted z_inj:
%   z_inj = v0j + sum(xi*vij).
%    The output signal (activation) of Zj is denoted zj:
%   zj = f(z_inj).
% w0k Bais on output unit k.
% Yk Output unit k.
% The net input to Yk is denoted y_ink:
%    y_ink = w0k + sum(zj*wjk)
%   the output signal (activation) of Yk is denoted yk:
%  yk = f(y_ink).
% Activation function:
% f(x) = 2/(1 + exp(-x)) -1
% with its derivative 
% f'(x) = 1/2*(1 + f(x))*(1-f(x))

%% Opening of the Input / Target Files
disp('Loading the input vector x and target vectors')
cd('E:\thesis\res\database\Face Database\ExtraFeatures\points_20');
TotalRecord = 1520;
x1 = ones(TotalRecord,40); x1 = single(x1);
t1 = ones(TotalRecord,5); t1 = logical(t1);
for var=1:TotalRecord  %1520
    [x1(var,:),t1(var,:)] = getFileData(sprintf('bioid_%04d.pts', var)); %row wise
end
r = randperm(1520);
for i=1:1520
    xA(i,:) = x1(r(i),:);
    tA(i,:) = t1(r(i),:);
end
% disp('Input vector') ,disp(x1)
% disp('Target vector'), disp(t1)

%% Enter the Architecture detail
disp('Enter the Architecture detail');
%n = input('Enter the no of input units');
%p = input('Enter the no of hidden units');
%m = input('Enter the no of output units');
n = 40; % INPUT
p = n/4; % HIDDEN
m = 5; % OUTPUT
% Tp = input('Enter the no of Training vectors');
Tp = TotalRecord / 10;
alpha = input('Enter the Learning rate :  ');
mov = struct('cdata',{},'colormap',{});

%% Preprocess the data
%[in,out,pf, tf] = imgHistGrayResizeMap(filename);

%% step 0 Initialization
if (nargin  < 1)
    disp('weights v and w are getting initialised randomly');
        v = -0.5+(0.5-(-0.5))*single(rand(n,p)); % int8(ones(n,p));  
        w  = -0.5+(0.5-(-0.5))*single(rand(p,m)); %int8(zeros(p,m)); 

        v0 = -0.5+(0.5-(-0.5))*rand(Tp,p);
        w0 = -0.5+(0.5-(-0.5))*rand(Tp,m);
end
% for T = 1:Tp     for i=1:n        x(T,i) = x1(T,i);    end
%    for i=1:m        t(T,i) = t1(T,i);    end end
chw = zeros(p,m);
chw0 = zeros(Tp,m);
chv = zeros(n,p);
chv0 = zeros(Tp,p);
dk = zeros(Tp,m);
yin = zeros(Tp,m);
y = zeros(Tp,m);
zin = zeros(Tp,p);
dinj = zeros(Tp,p);
dj =  zeros(Tp,p);
z =  zeros(Tp,p);
iteration =0;
er = 0; error = 0;

%% step 1 While stoping condition is false do step 2 -9
while er==0 % do Step 2-9
   disp(sprintf('Epoch number is %d and max error : %d min error : %d '  ...
               ,iteration, max(max(error)), min(min(error))));
    totalerr = 0;
% Step 2 For each Training pair, od Steps 3-8
    for trainingVec=1:Tp:TotalRecord % trainingVec is the steps (Tp) in inputs of X1
        x(1:Tp,:) = xA(trainingVec:trainingVec+Tp-1,:);
        tN(1:Tp,:) = tA(trainingVec:trainingVec+Tp-1,:);
        
%        [x,XS] = mapminmax(double(xN));    %xV = mapminmax('reverse',x,XS); 
        [t,TS] = mapminmax(double(tN));
%         tV = mapminmax('reverse',x,TS);

        zin =  x * v + v0;
        z = ((2./(1+exp(-zin)))-1);
%        z = tansig(zin);

        yin = z * w + w0;
%        y = tansig(yin);
        y = ((2./(1+exp(-yin)))-1); 
%        totalerr = 0.5 * ((t(T,j) - y(T,j))^2)+totalerr;

        dk = (t - y).*((1/2).*(1+y).*(1 - y));
%        dk = tansig('dn',y);
        for T=1:Tp
            for j =1:p
                chw(j,:) = alpha * dk(T,:) * z(T,j);
                dinj(T,j) = sum(dk(T,:) .* w(j,:));
                dj(T,j) = (dinj(T,j) * ((1/2) * (1 + z(T,j))* (1 - z(T,j))));
%                dj = tansig('dn',z);
                chv(:,j) = alpha * dj(T,j) * x(T,:);
%               chv(j,:) = alpha * dj(T,:) * x(T,j);
            end
        end
        chw0 = alpha * dk;
        chv0 = alpha * dj;           
        v  = v  + chv;
        v0 = v0 + chv0;
        w  = w  + chw;
        w0 = w0 + chw0;
        h1 = subplot(2,1,1);   surf(h1,im2double(v)); 
        h2 = subplot(2,1,2);   surf(h2,im2double(w));
        F(i) = getframe;
    end
%disp('value of y at this iteration');
%str = '';
%for i=1:5     str = strcat(str, sprintf('%d',B(i))); end
%disp(bin2dec(str))
%disp(y)
error = sqrt((t-y).^2);
interRep = dk^2;
errorRep = 1/2 * sum(interRep(:));
disp(sprintf('the max  error is %d',errorRep));
if max(max(error)) < 0.05
    er =1;
else
    er = 0;
end
iteration = iteration +1;
% alpha = alpha * .999;
%finerr = totalerr/(Tp*n);
%disp(finerr)
%if finerr < 0.01    er = 1; else    er = 0; end
%disp(sprintf('the error : %d, finerr : %d',error , finerr));
% img = error *255;
% img = padarray(img, [0  14]);
% mov(iteration).cdata = double(img);
% mov(iteration).colormap = [];
%codecs = videoWriter([],'codecs')
% if (iteration >=1500)
%     return;
% end
end %% End of wile loop Step 1
% movie2avi(mov, 'MatMov.avi', 'compression', 'Indeo5');
end %% End of Function / File