function [v,v0,w,w0, errorMat] = trainingBackPropagationNetRecordWise(v,v0,w,w0)
%Create an back propagation net
% x     Input training vector:
%    x = (x1, ..... xi, ..... xn)
% t     Output training vector:
%    t = (t1, ..... tk, ..... tm)
% sigmak Portion of error correction weight adjustment for wjk that is due
% to an error at the output unit Yk; also, the information about the error
% at unit Yk that is propagated back to the hidden units that feed into
% unit Yk
% sigmaj Portion of error correction weight adjustment for vij that is due
%to the backpropagation of error information from the output layer to the
%hidden unit Zj.
% alpha Learning rate
% Xi Input unit i:
%    For an input unit; the input signal and output signal are the same,
%    namely, xi.
% v0j Bais on the hidden unit j.
% Zj Hidden init j:
% The net input to Zj is denoted z_inj:
%   z_inj = v0j + sum(xi*vij).
%    The output signal (activation) of Zj is denoted zj:
%   zj = f(z_inj).
% w0k Bais on output unit k.
% Yk Output unit k.
% The net input to Yk is denoted y_ink:
%    y_ink = w0k + sum(zj*wjk)
%   the output signal (activation) of Yk is denoted yk:
%  yk = f(y_ink).
% Activation function:
% f(x) = 2/(1 + exp(-x)) -1
% with its derivative 
% f'(x) = 1/2*(1 + f(x))*(1-f(x))

%% Opening of the Input / Target Files
disp('Loading the input vector x and target vectors')
cd('E:\thesis\res\database\Face Database\ExtraFeatures\points_20');
TotalRecord = 1520;
x1 = ones(TotalRecord,40); x1 = single(x1);
t1 = ones(TotalRecord,5); t1 = logical(t1);
for var=1:TotalRecord  %TotalRecord
    [x1(var,:),t1(var,:)] = getFileData(sprintf('bioid_%04d.pts', var)); %row wise
end
% disp('Input vector') ,disp(x1)
% disp('Target vector'), disp(t1)


%% Enter the Architecture detail
disp('Enter the Architecture detail');
%n = input('Enter the no of input units');
%p = input('Enter the no of hidden units');
%m = input('Enter the no of output units');
n = 40; % INPUT
m = 5; % OUTPUT
p = n; % HIDDEN
% Tp = input('Enter the no of Training vectors');
Tp = round(TotalRecord / 10);
alpha = input('Enter the Learning rate :  ');

%% Preprocess the data
%[in,out,pf, tf] = imgHistGrayResizeMap(filename);

%% step 0 Initialization
if (nargin  < 1)
    disp('weights v and w are getting initialised randomly');
        v1 = -0.5+(0.5-(-0.5))*single(rand(n,p)); % int8(ones(n,p));  single
        w  = -0.5+(0.5-(-0.5))*single(rand(p,m)); %int8(zeros(p,m));  single

        f = 0.7 *((p)^(1/n));
        v0 = -f+(f+f)*rand(1,p);
        w0 = -0.5+(0.5-(-0.5))*rand(1,m);

    for i = 1:n
        for j=1:p
            v(i,j) = (f * v1(i,j))/(norm(v1(:,j)));
        end
    end
end
% for T = 1:Tp     for i=1:n        x(T,i) = x1(T,i);    end
%    for i=1:m        t(T,i) = t1(T,i);    end end
chw = zeros(p,m);
chw0 = zeros(1,m);
chv = zeros(n,p);
chv0 = zeros(1,p);
dk = zeros(Tp,m);
yin = zeros(Tp,m);
y = zeros(Tp,m);
zin = zeros(Tp,p);
dinj = zeros(Tp,p);
dj =  zeros(Tp,p);
z =  zeros(Tp,p);
iteration =0;
er = 0;
%% step 1 While stoping condition is false do step 2 -9
while er==0 % do Step 2-9
    disp(sprintf('Epoch number is %d',iteration))
    totalerr = 0;
% Step 2 For each Training pair, od Steps 3-8
    for trainingVec=1:Tp:TotalRecord % trainingVec is the steps (Tp) in inputs of X1
        x(1:Tp,:) = x1(trainingVec:trainingVec+Tp-1,:);
        t(1:Tp,:) = t1(trainingVec:trainingVec+Tp-1,:);
%        x = im2double(x);         t = im2double(t);
%        [x,XS] = mapminmax(double(xV)); [t,TS] = mapminmax(double(tV));
%       xV = mapminmax('reverse',x,XS);  tV = mapminmax('reverse',x,TS);
        for T=1:Tp % For loop Step 2
            for j =1:p
                zin(T,j) =  sum(x(T,:) .* v(:,j)') + v0(j);
                z(T,j) = ((2/(1+exp(-zin(T,j))))-1);
            end

            for j =1:m
                yin(T,j) = w0(j) + sum(z(T,:) .* w(:,j)');
                y(T,j) = ((2/(1+exp(-yin(T,j))))-1);
                totalerr = 0.5 * ((t(T,j) - y(T,j))^2)+totalerr;
                dk(T,j) = (t(T,j) - y(T,j))*((1/2)*(1+y(T,j))*(1 - y(T,j)));
            end
            for j =1:p
                chw(j,:) = alpha * dk(T,:) * z(T,j);
                dinj(T,j) = sum(dk(T,:) .* w(j,:));
                dj(T,j) = (dinj(T,j) * ((1/2) * (1 + z(T,j))* (1 - z(T,j))));
                chv(:,j) = alpha * dj(T,j) * x(T,:);
%                chv(j,:) = alpha * dj(T,:) * x(T,j);
            end
            chw0(:) = alpha * dk(T,:);
            chv0(:) = alpha * dj(T,:);            
            v  = v  + chv;
            v0 = v0 + chv0;
            w  = w  + chw;
            w0 = w0 + chw0;
        end % End of for loop Step 2
    end
disp('value of y at this iteration');
%str = '';
%for i=1:5     str = strcat(str, sprintf('%d',B(i))); end
%disp(bin2dec(str))
disp(y)
error = sqrt((t-y).^2);
if max(max(error)) < 0.05
    er =1;
else
    er = 0;
end
iteration = iteration +1;
finerr = totalerr/(Tp*n);
disp(finerr)

if finerr < 0.01
    er = 1;
else
    er = 0;
end
errorMat(iteration,:) = [max(max(error)), min(min(error))];
if( iteration  >= 300)
    return;
end
disp(sprintf('the error : %d, finerr : %d',error , finerr));
end %% End of wile loop Step 1
end %% End of Function / File