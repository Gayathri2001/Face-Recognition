function [A,B] = getFileData(InputFile)
fid = fopen(InputFile,'r');
% x1 = fread(fid,'*char');
fseek(fid, 29, 'bof');
A = fscanf(fid, '%g', 40);
% A = single(A);
%fseek(fid, 368, 'bof');
B = fscanf(fid, '%*c %d %*c %d %*c %d %*c %d %*c %d %*c %d %*c %d %*c %d %*c %d %*c %d %*c %d %*c %d %*c %d %*c %d %*c %d %*c %d %*c %d %*c %d %*c %d %*c %d %*c %d %*c %d %*c %d');
% B = logical(B);
fclose(fid);
