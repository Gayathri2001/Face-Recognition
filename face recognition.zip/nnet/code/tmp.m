clear,clc, close all
% 47.8
cd(fileparts(mfilename('fullpath')));
cd([pwd '/recordKeeping'])
DataBaseAll
cd('../../../res/database/Face Database/BioID-FaceDatabase-V1.2/')
861;
minNum = input('strating picture number');
maxNum = input('Ending picture number');
for i=1136:1146
    pic = imread(sprintf('BioID_%04d.pgm',i));
    figure, imshow(pic);
    title(sprintf('BioID %04d',i));
    hold on
    x1 = p(i,1:2:40);    y1 = p(i,2:2:40);
    plot(x1,y1,'r.');
end

