function trainBgdmE() %[v,v0,w,w0] = v,v0,w,w0)
%Create an back propagation neural network
%+++++++++++++++++++Formula formatted text in formulas++++++++++++
% Legends of Formatted Formula text 
%   _ (underscore) means Subscript
%   ^ (power)      means Superscript
%   () parenthesis is used for grouping, (openoffice uses {} instead).
%+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%%% Nomenclature
% p     Input training vector:
%           p = (p1, ..... pi, ..... pn)
% t     Output training vector:
%           t = (t1, ..... tk, ..... tm)
% d     Portion of error correction weight adjustment for w_(jk) that is 
%       due to an error at the output unit Y_k; also, the information about
%       the error at unit Y_k that is propagated back to the hidden units 
%       that feed into unit Y_k
% dj    Portion of error correction weight adjustment for v_(ij) that is 
%       due to the backpropagation of error information from the output 
%       layer to the hidden unit Z_j.
% alpha Learning rate
% P_i   Input unit i:
%       For an input unit; the input signal and output signal are the same,
%       namely, p_i.
% v0_j  Bais on the hidden unit j.
% Z_j   Hidden init j:
%       The net input to Z_j is denoted zin_j:
%           zin_j = v0_j + sum(p_i*v_(ij)).
%       The output signal (activation) of Zj is denoted zj:
%           z_j = f(zin_j).
% w0_k  Bais on output unit k.
% Y_k   Output unit k.
%       The net input to Yk is denoted y_ink:
%           yin_k = w0_k + sum(z_j*w_(jk))
%       The output signal (activation) of Yk is denoted yk:
%           y_k = f(yin_k).
%%% Activation function:
%           f(p) = 2/(1 + exp(-p)) -1
%       with its derivative 
%           f'(p) = 1/2*(1 + f(p))*(1-f(p))
%
%%% Training Algorithm
% Step 0.   Initialize Weights
%           (set to small random values (in the range -0.5 and 0.5, 
%           according to Nguyen-Widrow Initialization)
% Step 1.   While stopping condition is false, do Steps 2-9
%           Step 2.     For each training pair, do Steps 3-8
%%                       Feedforward:
%                       Step 3.     Each input unit (Pi, i = 1, ...,n)
%                                   receives input signal pi and broadcasts
%                                   this signal to all units in the layer
%                                   above (the hidden units).
%                       Step 4.     Each hidden unit (Zj, j=1, ...,p) sums
%                                   its weighted input signals,
%                                     zin_j = v0_j + ?_(i=1)^n p_i v_(ij)
%                                   applies its activation function to
%                                   compute its output signal,
%                                     z_j = f(zin_j),
%                                   and sends this signal to all units in
%                                   the layer above (output units).
%                       Step 5.     Each output unit (Y_k,k=1,...,m) sums
%                                   its weights input signals,
%                                     yin_k = w0_k + ?_(j=1)^p z_j w_(jk)
%                                   and applies its activation fuction to
%                                   compute its output signal,
%                                     y_k = f(yin_k).
%%                       BackPropagation of error:
%                       Step 6.     Each output unit (Y_k,k=1,...,m)
%                                   receives a target pattern corresponding
%                                   to the input training pattern, computes
%                                   its error information term,
%                                     d_k  =(t_k   - y_k)  f'(yin_k),
%                                   calculates its weight correction term
%                                   (used to update w_(jk) later),
%                                     chw_(jk) = alpha d_k z_j,
%                                   calculates its bais correction term
%                                   (used to update w0_k later),
%                                     chw0_k = alpha d_k,
%                                   and sends d_k to units in the layer
%                                   below.
%                       Step 7.     Each hidden unit (Z_j,j=1,...,p)
%                                   sums its delta inputs (from units in
%                                   the layer above),
%                                     din_j = ?_(k=1)^m d_k w_(jk),
%                                   multiplies by the derivative of its
%                                   activation function to calculate its 
%                                   error information term,
%                                     d_j  =din_j  f' (zin_j),
%                                   calculates its weight correction term
%                                   (used to update v_(ij) later),
%                                     chv_(ij) = alpha d_j p_i,
%                                   calculates its bais correction term
%                                   (used to update v0_j later),
%                                     chv0_j = alpha d_j.
%%                                   Update weights and baises:
%                       Step 8.     Each output unit (Y_k,k=1,...,m)
%                                   updates its bais and weights
%                                   (j=0,...,p):
%                                      w_(jk) (new) = w_(jk) (old) + chw_(jk),
%                                   Each hidden unit (Z_j,j=1,...,p)
%                                   updates its bais and weights
%                                   (i=0,...,n):
%                                      v_(ij) (new) = v_(ij) (old) + chv_(ij),
%           Step 9.     Test stopping condition.

%%  ==Step_0==Initialization=================================
    clc, clear all, close all
    %%% Opening of the Input / Target Files
    %tic, t = toc
    elapsed0 = clock; elapsed0(1:3) = []; elapsed0(1,3) =round(elapsed0(1,3));
    %%%
    cd(fileparts(mfilename('fullpath')))
    directory = pwd;
    disp('Loading the input vector p and target vectors')
    cd('../../');
    DataBaseAll
%     charData
    cd('elementWise');
    disp('Loading of input vector p and target vectors done')
    trainRecords = size(p,1);
    r = randperm(trainRecords);
    p1 = p; t1 = t;
    for i=1:trainRecords
        p(i,:) = p1(r(i),:);
        t(i,:) = t1(r(i),:); %tA
    end
    clear p1 t1
%  ----------------------------------------------------------
%%% Enter the Architecture detail
    disp('Enter the Architecture detail');
    e = 0.05; % error limit
    n = size(p,2);  %INPUT
    epa = input('Enter the maximum number of Epochs: [100] ');
    if isempty(epa),      epa = 100;    end
    h = input('Enter the number of Hidden neurons : [41] ');
    if isempty(h),        h = 41;    end
%     h = 41; %ceil(trainRecords*e); %  HIDDEN   Because W/p = e and 60% is 46, 100% is 76
    m = size(t,2); % OUTPUT
    alpha = input('Enter the Learning rate            : [0.01] ');
    if isempty(alpha),    alpha = 0.01;    end
    alp = input('Enter the Momentum rate : [0.2] ');
    if isempty(alp)       alp = 0.2;    end
%     beta = 0.7 * p^(1/n);
%  -----------------------------------------------------------    
if (nargin  < 2)
    disp('weights v and w are getting initialised randomly');
        v = randn(n,h); 
        v0 = randn(1,h); 
        w  = randn(h,m); 
        w0 = randn(1,m);
end
%%%Previous weights
        vOld  = v; 
        v0Old = v0; 
        wOld  = w; 
        w0Old = w0;
%%%First hidden Layer
    zin = zeros(trainRecords,h);
    z =  zeros(trainRecords,h);
    din = zeros(trainRecords,h);
    dj =  zeros(trainRecords,h);
    chv = zeros(n,h);
    chv0 = zeros(1,h);
%%%Output Layer
    yin = zeros(trainRecords,m);
    y = zeros(trainRecords,m);
    d = zeros(trainRecords,m);
    chw = zeros(h,m);
    chw0 = zeros(1,m);
iteration =1;
er = 0; error = 0; forceQuit = false; reason = '';

%%  ==Step_1==While_stoping_condition_is_false==do_step_2-9===
while er==0
%     totalerr = 0;
    errorMax(iteration) = max(max(error));
    disp(sprintf('Epoch : %9g, max err : %d', iteration, errorMax(iteration)));
%%% ==Step_2==For_Each_Training_pair===========do_Steps_3-8===
    for Tp=1:trainRecords
%% Feed forward:      
%%% ==Step_3==X_get_Input=====Already_done====================
%%% ==Step_4==================================================
%%% First Layer
        for j=1:h
            zin(Tp,j) = 0;
            for i=1:n
                zin(Tp,j) = zin(Tp,j) + p(Tp,i) * v(i,j);
            end
            zin(Tp,j) = v0(j) + zin(Tp,j);
             z(Tp,j) = (2/(1+exp(-zin(Tp,j))))-1; %activation function 
%             z(Tp,j) = (exp(zin(Tp,j))-exp(-zin(Tp,j)))/(exp(zin(Tp,j))+exp(-zin(Tp,j))); %activation function 
        end
%%% ==Step_5==================================================
    %%% Output Layer
        for k=1:m
            yin(Tp,k) = 0;
            for j=1:h
                yin(Tp,k) = yin(Tp,k) + z(Tp,j) * w(j,k);
            end
            yin(Tp,k) = w0(k) + yin(Tp,k);
%             y(Tp,k) = (2/(1+exp(-yin(Tp,k))))-1; %activation function 
             y(Tp,k) = 1/(1+exp(-yin(Tp,k))); %activation function 
%              y(Tp,k) = (exp(yin(Tp,k))-exp(-yin(Tp,k)))/(exp(yin(Tp,k))+exp(-yin(Tp,k))); %activation function 
    %        totalerr = 0.5 * ((t(T,j) - y(T,j))^2)+totalerr;
        end
%% Backpropagation of error (Training Started)
%%% ==Step_6==================================================
        for k=1:m
        d(Tp,k) = 0;
    %%% Error Info = (t - y) * (Derivative of Second layer activation function)
%        d(Tp,k) = (t(Tp,k) - y(Tp,k)) * ((1/2) *(1+y(Tp,k)) *(1 - y(Tp,k)));
        d(Tp,k) = (t(Tp,k) - y(Tp,k)) * (y(Tp,k) *(1 - y(Tp,k)));
            for j=1:h
                chw(j,k) = alpha * d(Tp,k) * z(Tp,j);
            end
            chw0(k) = alpha * d(Tp,k);
        end
%%% ==Step_7==================================================
        for j=1:h
            din(Tp,j) = 0;
            for k=1:m
                din(Tp,j) = din(Tp,j) + d(Tp,k) * w(j,k);
            end
            dj(Tp,j) = 0;
%%%     Error Info = din * (Derivative of First layer activation function)
           dj(Tp,j) = (din(Tp,j) * ((1/2) * (1 + z(Tp,j))* (1 - z(Tp,j))));
            for i=1:n
                chv(i,j) = alpha * dj(Tp,j) * p(Tp,i);
            end
            chv0(j) = alpha * dj(Tp,j);
        end
%% ==Step_8==Update_weights_and_biases========================
        if(iteration == 1)
            for k=1:m
                for j=1:h
                    w(j,k)=w(j,k)+chw(j,k);
                end
               w0(k)=w0(k)+chw0(k);
            end
            for j=1:h
                for i=1:n
                    v(i,j)=v(i,j)+chv(i,j);
                end
               v0(j)=v0(j)+chv0(j);
            end
        else
            for k=1:m
                for j=1:h
                    w(j,k)=w(j,k)+chw(j,k) + alp *(w(j,k) - wOld(j,k));
                end
               w0(k)=w0(k)+chw0(k) + alp *(w0(k) - w0Old(k));
            end
            for j=1:h
                for i=1:n
                    v(i,j)=v(i,j)+chv(i,j) + alp *(v(i,j) - vOld(i,j));
                end
               v0(j)=v0(j)+chv0(j) + alp *(v0(j) - v0Old(j));
            end
        end
        wOld = w;
        w0Old = w0;
        vOld = v;
        v0Old = v0;
    end
%%  ==Step_9==Test_stoping_condition==========================
    error = sqrt((t-y).^2);
    %%% Update the stopping condition variable
    if max(max(error)) < e % W/P = e, W =weights,P =inputs, e = errors
        er =1;
    else
        er = 0;
    end
    if (iteration > epa) 
        forceQuit = true;
        reason = 'Maximum nos of Epoch reached';
        break
    elseif ((iteration ~= 1 ) && (abs(errorMax(iteration) - errorMax(iteration-1)) < 5.0e-008))
%         forceQuit = true;
%         reason = 'Minimum gradient reached';
%         break
        disp(sprintf('Minimum gradient reached \n weights reinitialized'))
        v  = v  - randn(n,h); 
        v0 = v0 - randn(1,h); 
        w  = w  - randn(h,m); 
        w0 = w0 - randn(1,m);
    end
    iteration = iteration +1;
end %% End of while loop Step 1
%% ==GUI======Display_of_the_results=============================
erLine = ones(1,size(errorMax,2))*0.05;
clf('reset'), cla reset
plot(1:size(errorMax,2),errorMax, 1:size(errorMax,2),erLine,'r')
xlabel('iteration '), ylabel('error '), title('Plot of the error')
text(size(erLine,2)-50,0.02,'\uparrow\rightarrow  Goal', ...
'FontSize',8, 'Color',[1 0 0],'Units','data');
elapsed1 = clock; elapsed1(1:3) = []; elapsed1(1,3) =round(elapsed1(1,3));
elapsed = elapsed1 - elapsed0; clear elapsed0 elapsed1
if(~forceQuit)
    text(.53, .85, ['{\fontsize{16}\color{blue}Converged}', ...
        sprintf('\nElapsed time  :%2.0f:%2.0f:%2.0f\n',elapsed), ...
        '\fontsize{10}\color[rgb]{0 .5 .5}\alpha                   : ', ...
        sprintf('%1.2f',alpha), ...
        sprintf('\n'), '\mu                   : ', sprintf('%1.1f',alp)...
        ],'Units','normalized');
    save([directory, '\weight6040.dat'],'v','v0','w','w0') %, 'p','tA');
else
    text(.53, .72, ['{\fontsize{16}\color{red}Diverged}', ...
        sprintf('\nElapsed time  :%2.0f:%2.0f:%2.0f\n',elapsed), ...
        '\fontsize{10}\color[rgb]{0 .5 .5}\alpha                   : ', ...
        sprintf('%1.2f\n',alpha), ...
        sprintf('\n'), '\mu                   : ', sprintf('%1.1f',alp)...
        '\fontsize{8}\color[rgb]{.5 .5 0}Reason =', sprintf('%s',reason)], ...
        'Units','normalized');
%     msgbox('Maximum number of Epoch reached with out convergence','No convergence')
    disp(sprintf('\t{{{{{{Diverged}}}}}} \n %s\n',reason))
end
if ((errorMax(1,size(errorMax,2))+0.1) > 1 || ((size(errorMax,2)-50) < 50))
    text(size(errorMax,2),errorMax(1,size(errorMax,2))- 0.1,...
        [sprintf('Last Epoch : %0.0f',max(iteration)-1), ...
        '^{th} out of ', sprintf('%0.0f     \n',epa), ...
        sprintf('Last Error : %10d',errorMax(max(iteration)-1)), ...
        '\uparrow  '], 'FontSize',8, 'HorizontalAlignment', 'right', ...
        'Units','data');
else
    text(size(errorMax,2)-50,errorMax(1,size(errorMax,2))+0.1,...
        [sprintf('Last Epoch : %0.0f',max(iteration)-1), ...
        '^{th} out of ', sprintf('%0.0f     \n',epa), ...
        sprintf('Last Error : %10d\n',errorMax(max(iteration)-1)), ...
        '\downarrow  '], 'FontSize',8, 'HorizontalAlignment', 'right', ...
        'Units','data');    
end
end %% End of Function / File