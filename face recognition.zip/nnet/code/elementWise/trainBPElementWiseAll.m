function [v,v0,w,w0] = trainBPElementWiseAll(v,v0,w,w0)
%% Opening of the Input / Target Files
cd(getenv('thesis'))
paths
disp('Loading the input vector x and target vectors')
cd(strcat(getenv('thesis'),'\res\database\Face Database\ExtraFeatures\points_20'));
TotalRecord = 1520;
x = zeros(TotalRecord,40); x = single(x);
t1 = false(TotalRecord,5);
for var=1:TotalRecord  
    [x1(var,:),t1(var,:)] = getFileData(sprintf('bioid_%04d.pts', var)); %row wise
end
r = randperm(TotalRecord);
for i=1:TotalRecord
    x(i,:) = x1(r(i),:);
    tA(i,:) = t1(r(i),:);
end
[t,TS] = mapminmax(double(tA),-.9,.9);
t = single(t);
clear r tA thesis train var % x1 t1

%% Enter the Architecture detail
disp('Enter the Architecture detail');
n = 40;  %INPUT      
p = 2; %n/4;  HIDDEN     Because W/p = e and 60% is 46, 100% is 76
m = 5; % OUTPUT
alpha = input('Enter the Learning rate :  ');
alp = input('Enter the Momentum rate :  ');
% alpha = 0.025; alp = 0.2;

%% step 0 Initialization
if (nargin  < 2)
    disp('weights v and w are getting initialised randomly');
        v = -0.5+(0.5-(-0.5))*single(rand(n,p)); % int8(ones(n,p));  
        w  = -0.5+(0.5-(-0.5))*single(rand(p,m)); %int8(zeros(p,m)); 

        v0 = -0.5+(0.5-(-0.5))*rand(1,p);
        w0 = -0.5+(0.5-(-0.5))*rand(1,m);
end
%%%First hidden Layer
    chv = zeros(n,p);
    chv0 = zeros(1,p);
    zin = zeros(TotalRecord,p);
    dinj = zeros(TotalRecord,p);
    dj =  zeros(TotalRecord,p);
    z =  zeros(TotalRecord,p);
%%%Second hidden Layer
    chw = zeros(p,m);
    chw0 = zeros(1,m);
    dk = zeros(TotalRecord,m);
    yin = zeros(TotalRecord,m);
    y = zeros(TotalRecord,m);
iteration =1;
er = 0; error = 0; %errorRep = 0;

%%% step 1 While stoping condition is false do step 2 -9
while er==0 % do Step 2-9
    errorMax(iteration) = max(max(error));
    disp(sprintf('Epoch : %4g, max err : %d',iteration, errorMax(iteration)));
%     totalerr = 0;
%%% Step 2 For each Training pair, do Steps 3-8
    for Tp=1:TotalRecord
%% Feed forward:        
    %%% First Layer
        for j=1:p
            for i=1:n
                zin(Tp,j) = zin(Tp,j) + x(Tp,i) * v(i,j);
            end
            zin(Tp,j) = v0(j) + zin(Tp,j);
%             z(Tp,j) = ((2/(1+exp(-zin(Tp,j))))-1); %activation function 
            z(Tp,j) = tansig(zin(Tp,j)); %activation function 
        end
    %%% Second Layer
        for k=1:m
            for j=1:p
                yin(Tp,k) = yin(Tp,k) + z(Tp,j) * w(j,k);
            end
            yin(Tp,k) = w0(k) + yin(Tp,k);
%             y(Tp,k) = ((2/(1+exp(-yin(Tp,k))))-1); %activation function 
            y(Tp,k) = tansig(yin(Tp,k)); %activation function 
    %        totalerr = 0.5 * ((t(T,j) - y(T,j))^2)+totalerr;
        end
%% Backpropagation of error (Training Started)
        for k=1:m
    %%% Error Info = Derivative of Second layer activation function * (t - y)
%        dk(Tp,k) = (t(Tp,k) - y(Tp,k)) * ((1/2) *(1+yin(Tp,k)) *(1 - yin(Tp,k)));
         dk(Tp,k) = (t(Tp,k) - y(Tp,k)) * tansig('dn',yin(Tp,k));
        end
        for j=1:p
            for k=1:m
                chw(j,k) = alpha * dk(Tp,k) * z(Tp,j);
                chw0(k) = alpha * dk(Tp,k);
            end
        end
        for j=1:p
            for k=1:m
                dinj(Tp,j) = dinj(Tp,j) + dk(Tp,k) * w(j,k);
            end
%%%     Error Info = Derivative of First layer activation function * dinj
%           dj(Tp,j) = (dinj(Tp,j) * ((1/2) * (1 + zin(Tp,j))* (1 - zin(Tp,j))));
            dj(Tp,j) = dinj(Tp,j) * tansig('dn',zin(Tp,j));
        end
        for j=1:p        
            for i=1:n
                chv(i,j) = alpha * dj(Tp,j) * x(Tp,i);
            end
            chv0(j) = alpha * dj(Tp,j);
        end
%% Step 8 Update weights and biases
        for j=1:p
            for i=1:n
                v(i,j)=v(i,j)+chv(i,j);
            end
           v0(j)=v0(j)+chv0(j);
        end
        for k=1:m
            for j=1:p
                w(j,k)=w(j,k)+chw(j,k);
            end
           w0(k)=w0(k)+chw0(k);
        end
    end
    error = sqrt((t-y).^2);
    %%% Step 9 Update the stopping condition variable
    if max(max(error)) < 0.05 % W/P = e, W =weights,P =inputs, e = errors
        er =1;
    else
        er = 0;
    end
    iteration = iteration +1;
end %% End of wile loop Step 1
save('weight6040.dat','v','v0','w','w0') %, 'x','tA');
clf('reset'), cla reset, plot(errorMax)
xlabel('iteration '), ylabel('error '), title('Plot of the error')
end %% End of Function / File