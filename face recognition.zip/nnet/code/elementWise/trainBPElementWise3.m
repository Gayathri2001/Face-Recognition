function [v,v0,w,w0] = trainBPElementWise(v,v0,w,w0)
%%  ==Step_0==Initialization=================================
%%% Enter the Architecture detail
    disp('Enter the Architecture detail');
    e = 0.05; % error limit
    n = 40;  %INPUT
    m = 5; % OUTPUT
    alpha = input('Enter the Learning rate :  ');
    alp = input('Enter the Momentum rate :  ');
    % alpha = 0.025; alp = 0.2;
%  -----------------------------------------------------------
%%% Opening of the Input / Target Files
%tic, t = toc
    cd(getenv('thesis'))
    paths
    disp('Loading the input vector x and target vectors')
    cd(strcat(getenv('thesis'),'\res\database\Face Database\ExtraFeatures\points_20'));
    FaceDataset = FaceDatabase;
    train = D6040(FaceDataset);
    trainRecords = sum(train(:));
    p = ceil(trainRecords*e); %  1st HIDDEN   Because W/p = e and 60% is 46, 100% is 76
    q = p; % 2nd Hidden Layer limit
    beta = 0.7 * p^(1/n);
    x = zeros(trainRecords,n); x = single(x);
    t1 = false(trainRecords,m);
    fileset = filesetter(FaceDataset, train);
    for var=1:trainRecords  
        [x1(var,:),t1(var,:)] = getFileData(fileset(var,:)); %row wise
    end
    r = randperm(trainRecords);
    for i=1:trainRecords
        x(i,:) = x1(r(i),:);
        tA(i,:) = t1(r(i),:);
    end
    [t,TS] = mapminmax(double(tA),-.9,.9);
    x1 = x;
    [x(1,:),ps] = mapminmax(double(x1(1,:)));
    for o =2:trainRecords
        x(o,:) = mapminmax('apply',double(x1(o,:)),ps);
    end
    x = single(x);
    t = single(t);
    clear x1 t1 r tA thesis train var o
%  ----------------------------------------------------------
if (nargin  < 2)
    disp('weights v and w are getting initialised randomly');
        u = randc(n,q); 
        v = randc(q,p); 
        w  = randc(p,m);
        v0 = randc(1,p);
        w0 = randc(1,m);
        
        uh = sqrt(sum(u.^2));
        for h =1:q
            u(:,h) = (beta * u(:,h)) ./ uh(h);
        end
        u0 = rand(1,q)-beta*ones(1,q);
end
%%%First hidden Layer
    zin  = zeros(trainRecords,q);
    z    = zeros(trainRecords,q);
    dinh = zeros(trainRecords,q);
    dh   = zeros(trainRecords,q);
    chu  = zeros(n,q);
    chu0 = zeros(1,q);
%%%Second hidden Layer
    zzin  = zeros(trainRecords,p);
    zz    = zeros(trainRecords,p);
    dinj = zeros(trainRecords,p);
    dj   = zeros(trainRecords,p);
    chv  = zeros(p,p);
    chv0 = zeros(1,p);
%%%Third hidden Layer
    yin  = zeros(trainRecords,m);
    y    = zeros(trainRecords,m);
    dk   = zeros(trainRecords,m);
    chw  = zeros(p,m);
    chw0 = zeros(1,m);

iteration =1;
er = 0; error = 0; %errorRep = 0;

%%  ==Step_1==While_stoping_condition_is_false==do_step_2-9===
while er==0
    errorMax(iteration) = max(max(error));
    disp(sprintf('Epoch : %4g, max err : %d',iteration, errorMax(iteration)));
%     totalerr = 0;
%%% ==Step_2==For_Each_Training_pair===========do_Steps_3-8===
    for Tp=1:trainRecords
%% Feed forward:      
%%% ==Step_3==X_get_Input=====================================
%%% ==Step_4==================================================
%%% First Layer
        for h=1:q
            for i=1:n
                zin(Tp,h) = zin(Tp,h) + x(Tp,i) * u(i,h);
            end
            zin(Tp,h) = u0(h) + zin(Tp,h);
%             z(Tp,h) = (2/(1+exp(-zin(Tp,h))))-1; %activation function 
            z(Tp,h) = (exp(zin(Tp,h))-exp(-zin(Tp,h)))/(exp(zin(Tp,h))+exp(-zin(Tp,h))); %activation function 
%            z(Tp,h) = tansig(zin(Tp,h)); %activation function 
        end
%%% ==Step_5==================================================
    %%% Second Layer
        for j=1:p
            for h=1:q
                zzin(Tp,j) = zzin(Tp,j) + z(Tp,h) * v(h,j);
            end
            zzin(Tp,j) = v0(j) + zzin(Tp,j);
%             y(Tp,j) = (2/(1+exp(-zzin(Tp,j))))-1; %activation function 
             zz(Tp,j) = (exp(zzin(Tp,j))-exp(-zzin(Tp,j)))/(exp(zzin(Tp,j))+exp(-zzin(Tp,j))); %activation function 
%            y(Tp,j) = tansig(zzin(Tp,j)); %activation function 
    %        totalerr = 0.5 * ((t(T,j) - y(T,j))^2)+totalerr;
        end
%%% ==Step_5-2==================================================
    %%% Third Layer
        for k=1:m
            for j=1:p
                yin(Tp,k) = yin(Tp,k) + zz(Tp,j) * w(j,k);
            end
            yin(Tp,k) = w0(k) + yin(Tp,k);
%             y(Tp,k) = (2/(1+exp(-yin(Tp,k))))-1; %activation function 
             y(Tp,k) = (exp(yin(Tp,k))-exp(-yin(Tp,k)))/(exp(yin(Tp,k))+exp(-yin(Tp,k))); %activation function 
%            y(Tp,k) = tansig(yin(Tp,k)); %activation function 
    %        totalerr = 0.5 * ((t(T,j) - y(T,j))^2)+totalerr;
        end
%% Backpropagation of error (Training Started)
%%% ==Step_6==================================================
        for k=1:m
    %%% Error Info = (t - y) * (Derivative of Second layer activation function)
%        dk(Tp,k) = (t(Tp,k) - y(Tp,k)) * ((1/2) *(1+y(Tp,k)) *(1 - y(Tp,k)));
        dk(Tp,k) = (t(Tp,k) - y(Tp,k)) * ((1+y(Tp,k)) *(1 - y(Tp,k)));
%         dk(Tp,k) = (t(Tp,k) - y(Tp,k)) * tansig('dn',yin(Tp,k));
            for j=1:p
                chw(j,k) = alpha * dk(Tp,k) * zz(Tp,j);
            end
            chw0(k) = alpha * dk(Tp,k);
        end
%%% ==Step_7==================================================
        for j=1:p
            for k=1:m
                dinj(Tp,j) = dinj(Tp,j) + dk(Tp,k) * w(j,k);
            end
%%%     Error Info = dinj * (Derivative of First layer activation function)
%           dj(Tp,j) = (dinj(Tp,j) * ((1/2) * (1 + z(Tp,j))* (1 - z(Tp,j))));
           dj(Tp,j) = dinj(Tp,j) * ((1 + zz(Tp,j))* (1 - zz(Tp,j)));
%            dj(Tp,j) = dinj(Tp,j) * tansig('dn',zin(Tp,j));
            for h=1:q
                chv(h,j) = alpha * dj(Tp,j) * z(Tp,h);
            end
            chv0(j) = alpha * dj(Tp,j);
        end
%%% ==Step_7-2==================================================
        for h=1:q
            for j=1:p
                dinh(Tp,h) = dinh(Tp,j) + dj(Tp,j) * v(h,j);
            end
%%%     Error Info = dinj * (Derivative of First layer activation function)
%           dj(Tp,j) = (dinj(Tp,j) * ((1/2) * (1 + z(Tp,j))* (1 - z(Tp,j))));
           dh(Tp,h) = dinh(Tp,h) * ((1 + z(Tp,h))* (1 - z(Tp,h)));
%            dj(Tp,j) = dinj(Tp,j) * tansig('dn',zin(Tp,j));
            for i=1:n
                chu(i,h) = alpha * dh(Tp,h) * x(Tp,i);
            end
            chu0(h) = alpha * dj(Tp,h);
        end
%% ==Step_8==Update_weights_and_biases========================
        for k=1:m
            for j=1:p
                w(j,k)=w(j,k)+chw(j,k);
            end
           w0(k)=w0(k)+chw0(k);
        end
        for j=1:p
            for h=1:q
                v(h,j)=v(h,j)+chv(h,j);
            end
           v0(j)=v0(j)+chv0(j);
        end
        for h=1:q
            for i=1:n
                u(i,h)=u(i,h)+chu(i,h);
            end
           u0(h)=u0(h)+chu0(h);
        end
    end
%%  ==Step_9==Test_stoping_condition==========================
    error = sqrt((t-y).^2);
    %%% Update the stopping condition variable
    if max(max(error)) < e % W/P = e, W =weights,P =inputs, e = errors
        er =1;
    else
        er = 0;
    end
    iteration = iteration +1;
end %% End of wile loop Step 1
save('weight6040.dat','v','v0','w','w0') %, 'x','tA');
clf('reset'), cla reset, plot(errorMax)
xlabel('iteration '), ylabel('error '), title('Plot of the error')
end %% End of Function / File