function [x ,t] = get25Records
directory = cd(fileparts(mfilename('fullpath')));
cd('../../../')
paths
cd(sprintf('%s',directory))
FaceDataset = FaceDatabase;
totalSets = FaceDataset.fields;
item = 1;
for i=1:totalSets
    total = size(FaceDataset.(sprintf('d%d',i)),2);
    if total < 25
        continue
    else
        for j=1:25
            fileset(item,:) = sprintf('bioid_%04d.pts', FaceDataset.(sprintf('d%d',i))(j));
            item = item + 1;
        end
    end
end
for variable=1:size(fileset,1)  
    [x(variable,:),t(variable,:)] = getFileData(fileset(variable,:)); %row wise
end
