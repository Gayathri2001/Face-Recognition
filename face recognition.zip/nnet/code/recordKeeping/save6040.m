function save6040(recs)
    directory =cd(fileparts(mfilename('fullpath')));
    cd('../../../')
    paths
    cd(sprintf('%s',directory))
    FaceDataset = FaceDatabase;
    totalSets = FaceDataset.fields;
    trainRec = floor(60/100 *recs); testRec = floor(40/100 *recs);
    totalRec = trainRec + testRec ;
%% Train Records
    item = 1;
    p = zeros(trainRec,40); t = zeros(trainRec,23); persons = 0; val = 0;
    for i=1:totalSets
        if(size(FaceDataset.(sprintf('d%d',i)),2) < totalRec) 
            continue
        else
            val = val +1;
            persons(val) = i;
            for j=1:trainRec
                fileset(item,:) = sprintf('bioid_%04d.pts', FaceDataset.(sprintf('d%d',i))(j));
                item = item + 1;
            end
        end
    end
    for variable=1:size(fileset,1)  
        [p(variable,:),t(variable,:)] = getFileData(fileset(variable,:)); %row wise
    end
    cd('..\preprocessing')
    p =RTSInvariant(p);
    cd(sprintf('%s',directory))    
    save(sprintf('trainRec%d',recs),'p','t','persons')
%     p1 = p; t1 = t; persons1 = persons;
    clear p t persons fileset thesis val
%% test Records 
    item = 1;
    p = zeros(testRec,40); t = zeros(testRec,23); persons = 0; val = 0;
    for i=1:totalSets
        if(size(FaceDataset.(sprintf('d%d',i)),2) < totalRec) 
            continue
        else
            val = val +1;
            persons(val) = i;
            for j=trainRec+1:testRec+trainRec
                fileset(item,:) = sprintf('bioid_%04d.pts', FaceDataset.(sprintf('d%d',i))(j));
                item = item + 1;
            end
        end
    end
    for variable=1:size(fileset,1)  
        [p(variable,:),t(variable,:)] = getFileData(fileset(variable,:)); %row wise
    end
    cd('..\preprocessing')
    p =RTSInvariant(p);
    cd(sprintf('%s',directory))
    save(sprintf('testRec%d',recs),'p','t','persons')
%     p2 = p; t2 = t; persons2 = persons;
%     s = struct('p1',p1,'t1',t1,'persons1',persons1,'p2',p2,'t2',t2,'persons2',persons2);
