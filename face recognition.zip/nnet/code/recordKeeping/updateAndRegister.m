function updateAndRegister(registerNewUser, yesNo)
% clear, clc
cd(fileparts(mfilename('fullpath')))
cd ..\..\..\res\database\'Face Database'\ExtraFeatures\
recycle on;
if exist('points_20', 'dir')
    rmdir('points_20','s')
%     cd ..\..\..\
end
unzip('bioid_pts.zip')
cd points_20
TargetSz  = registerNewUser.newID;
ID             = registerNewUser.ID;
IDStr        = registerNewUser.IDStr;
if isequal(yesNo, 'true')
    insertAndUpdate(ID, IDStr);
else
    fprintf(1, '%s \n %s \n', 'updateAndRegister oparating in just update mode, ', ...
    ' no new recods are inserted');
    TargetSz  = TargetSz - 1;
end
FaceDataset = FaceDatabase;
totalSets = FaceDataset.fields;
item = 1;
persons = 0; val = 0;
for i=1:totalSets % By person (class )
    val = val +1;
    persons(val) = i;
    for j=1:size(FaceDataset.(sprintf('d%d',i)),2) % By records of person
        fileset(item,:) = sprintf('bioid_%04d.pts', FaceDataset.(sprintf('d%d',i))(j));
        item = item + 1;
    end
    str = ' ';
turnedOn = TargetSz - i + 1;
    for targetBaseTemplate =1:TargetSz
        if isequal(targetBaseTemplate, turnedOn)
            b(targetBaseTemplate) = 1;
        else
            b(targetBaseTemplate) = 0;
        end
    end
    for targetBlackTemplate=1:TargetSz
        if (targetBlackTemplate ~= TargetSz)
            str = strcat(str , [sprintf('%d ',b(targetBlackTemplate)) ',']);
        else
            str = strcat(str , sprintf('%d %c ',b(targetBlackTemplate),';'));
        end
    end
    for variable=1:size(fileset,1)  
        fid = fopen(fileset(variable,:),'r+');
        status = fseek(fid, -3, 'eof');
        if (status == -1)     return, end
        count = fwrite(fid,str,'*char'); %,0,'ieee-le');
        if (count <= 0)
            msgbox(sprintf('Unable to write the file %s %d character written',fileset(variable,:),count))
        end
        fwrite(fid,'}','*char');
        fclose(fid);
    end
    item = 1; clear fileset;
end
fprintf(1, '%s \n', 'All files had been written');

function insertAndUpdate(ID , IDStr)
% clear, clc
% ID = 'd24'; IDStr = 'd24 = [ 1600:1700];';
cd ..\..\..\..\..\nnet\code\recordKeeping\
fid=fopen('FaceDatabase.m');
tline = fgetl(fid);
% tline = fgetl(fid); tline = fgetl(fid); tline = fgetl(fid); tline = fgetl(fid); tline = fgetl(fid);
index = 1; 
max = size(tline, 2);
FileBuffer = ''; tmpFileBuffer = '';
while ischar(tline)
    if(size(tline, 2) > max)
        str2padd = blanks(size(tline, 2) - max);
        for i = 1:size(FileBuffer,1)
            tmpFileBuffer(i,:) = [FileBuffer(i,:) str2padd];
        end
        FileBuffer = tmpFileBuffer; clear tmpFileBuffer;
        FileBuffer(index, :) = tline;
        max = size(tline, 2);
    else
        FileBuffer(index, :) = [tline blanks(size(FileBuffer, 2) - size(tline, 2))];
    end
    tline = fgetl(fid);
    index = index + 1;
end
fclose(fid);

%% Insert the record
for i =1:size(FileBuffer,1)
    if strfind(FileBuffer(i,:), '<<Insert_RecordNumbers>>');
        insertRecord = i;
    elseif strfind(FileBuffer(i,:), '<<Insert_Total>>');
        InsertTotal = i + 1;
    elseif strfind(FileBuffer(i,:), '<<Insert_Recs>>');
        InsertRecs = i + 2;
    elseif strfind(FileBuffer(i,:), '<<Insert_FaceDataset>>');
        InsertFaceDataset = i + 3;
    elseif strfind(FileBuffer(i,:), '<<Insert_Clear>>');
        InsertClear = i + 4;
    else
        continue
    end
end
%% Insertion of ID plus Records numbers
tmpFileBuffer = FileBuffer;
for i = insertRecord:size(FileBuffer,1)
    tmpFileBuffer(i+1, :) = FileBuffer(i, :); % creating a blank line (deplicate tag line)
end
 FileBuffer = tmpFileBuffer; clear tmpFileBuffer
% inert the ID plus new recordNumber on blank line
if size(IDStr, 2) < size(FileBuffer,2)
    FileBuffer(insertRecord, :) = [IDStr blanks(size(FileBuffer, 2) - size(IDStr, 2))];
elseif size(IDStr, 2) > size(FileBuffer,2)
    tmpFileBuffer = FileBuffer;
    str2padd = blanks(size(IDStr, 2) - size(FileBuffer,2));
    for i = 1:size(FileBuffer,1)
        tmpFileBuffer(i,:) = [FileBuffer(i,:) str2padd];
    end
    FileBuffer = tmpFileBuffer; clear tmpFileBuffer;
    FileBuffer(insertRecord, :) = IDStr;
else
    FileBuffer(insertRecord, :) = IDStr;
end

%% Update the total + fields etc
%  + size( Name eval(ID),2) ... % InsertTotal -1
FileBuffer = InsertTag(InsertTotal, ['+ size(' ID ',2) ...'], FileBuffer);
% size(Name eval(ID),2), ... % InsertRecs -1
FileBuffer = InsertTag(InsertRecs, ['size(' ID ',2), ...'] , FileBuffer);
% ID , Name eval(ID)  ... % InsertFaceDataset -1
FileBuffer = InsertTag(InsertFaceDataset, [',''' ID ''', ' ID ' ... '], FileBuffer);
%  Name eval(ID) ... % InsertClear -1
FileBuffer = InsertTag(InsertClear, [ID ' ...'], FileBuffer);
%% write FileBuffer
fid=fopen('FaceDatabase.m', 'w');
    for i =1:size(FileBuffer,1)
        fwrite(fid, FileBuffer(i, :), '*char');
        fwrite(fid, sprintf('\n'), '*char');
    end
fclose(fid);

function FileBuffer = InsertTag(tagLine, str, FileBuffer)
% Insert blank line
tmpFileBuffer = FileBuffer;
for i = tagLine:size(FileBuffer,1)
    tmpFileBuffer(i+1, :) = FileBuffer(i, :); % creating a blank line (deplicate tag line)
end
 FileBuffer = tmpFileBuffer; clear tmpFileBuffer
% Paste the string on the blank line
FileBuffer(tagLine, :) = [blanks(8) str blanks(size(FileBuffer, 2) - size(str, 2) - 8)];