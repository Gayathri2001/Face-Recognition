function writeTargets(newData)
cd(fileparts(mfilename('fullpath')))
cd('..\..\..\res\database\Face Database\ExtraFeatures\bioid_pts18\points_20')
count = 0;
if nargin < 1
    startFile = input('Input the file no to start with: ');
    endFile = input('Input the file no to end on: ');
    values = input('Input the values : ');
else
    startFile = newData.startFile;
    endFile = newData.endFile;
    values = newData.values;
end
for i=startFile:endFile
    writeFile(sprintf('bioid_%04d.pts',i),values);
    count = count +1;
end
disp(sprintf('%d files written',count))
