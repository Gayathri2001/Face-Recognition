function [trainRec, testRec] = D6040(FaceDataset, per)
if (nargin < 2)
    per = 60;
end
totalSets = FaceDataset.fields;
trainRec = zeros(1,totalSets);
testRec = zeros(1,totalSets);
for i=1:totalSets
    total = size(FaceDataset.(sprintf('d%d',i)),2);
    trainRec(i) = floor(per/100 *total);
   testRec(i) = total - trainRec(i);
end