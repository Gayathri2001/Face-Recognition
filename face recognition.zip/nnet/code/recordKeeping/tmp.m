%% Documentations
% Doc -> learned person on moment = thousand years of praying
%       reg -> lot of AI, especially Neural net
% New doc of new softwares, plus
% Visio diagrams of new and old programs

%% Code
% recs on line 93 of createNewDataset, plus
%sprintf(
clear, clc
dialogMsg = '{\fontsize{18}\color{red}The network already exists, You want to overwrite it } ';
dialogTitle =  'Overwrite the neural network';
options.Interpreter = 'tex';
options.Default = 'Cancel';
selection = questdlg( dialogMsg, dialogTitle, 'Overwrite', 'Cancel', options);