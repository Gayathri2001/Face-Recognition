function count = writeFile(InputFile,b)
%b = [0; 0; 0; 0; 1];
str = ' ';
for i=1:size(b,2)
    if (i ~= size(b,2))
        str = strcat(str , [sprintf('%d ',b(i)) ',']);
    else
        str = strcat(str , sprintf('%d %c ',b(i),';'));
    end
end
fid = fopen(InputFile,'r+');
status = fseek(fid, -3, 'eof');
%status = fseek(fid, 368, 'bof'); %368
if (status == -1)     return, end
count = fwrite(fid,str,'*char'); %,0,'ieee-le');
if (count <= 0)
    msgbox(sprintf('Unable to write the file %s %d character written',InputFile,count))
end
fwrite(fid,'}','*char');
fclose(fid);