function s = Records(noRec)
% clear,clc
% close all
directory =cd(fileparts(mfilename('fullpath')));
cd('../../../')
paths
cd(sprintf('%s',directory))
FaceDataset = FaceDatabase;
totalSets = FaceDataset.fields;
item = 1;
p = zeros(noRec,40); t = zeros(noRec,23); persons = 0;
for i=1:totalSets
    if(size(FaceDataset.(sprintf('d%d',i)),2) < noRec) 
        continue
    else
        persons = persons + 1;
        for j=1:noRec
            fileset(item,:) = sprintf('bioid_%04d.pts', FaceDataset.(sprintf('d%d',i))(j));
            item = item + 1;
        end
    end
end
for variable=1:size(fileset,1)  
    [p(variable,:),t(variable,:)] = getFileData(fileset(variable,:)); %row wise
end
s = struct('p',p,'t',t,'persons',persons);