function replicatedRecords()
    % clear,clc, close all
    % directory =cd(fileparts(mfilename('fullpath')));
    % % DataBaseAll
    % cd('../../../')
    % paths
    % cd(sprintf('%s',directory))
    FaceDataset = FaceDatabase;
    totalSets = FaceDataset.fields;
    trainRec = zeros(1,totalSets);
    testRec = zeros(1,totalSets);
    fullTrainRec = 60/100 * FaceDataset.maxRec; 
    fullTestRec = 40/100 * FaceDataset.maxRec;
    for i=1:totalSets
        total = FaceDataset.recs(i);
        trainRec(i) = ceil(60/100 *total);
        testRec(i) = floor(40/100 *total);
    end
    trItem = 1; tsItem = 1;
    for i=1:totalSets
        trSz = trainRec(i); tsSz = testRec(i);
        for j=1:trSz
            trFileset(trItem,:) = sprintf('bioid_%04d.pts', FaceDataset.(sprintf('d%d',i))(j));
            trItem = trItem + 1;
        end
        for j=1:tsSz
            tsFileset(tsItem,:) = sprintf('bioid_%04d.pts', FaceDataset.(sprintf('d%d',i))(j));
            tsItem = tsItem + 1;
        end
        [trFileset, trItem] = padding(i, FaceDataset, trFileset, fullTrainRec, trItem, trSz);
        [tsFileset, tsItem] = padding(i, FaceDataset, tsFileset, fullTestRec, tsItem, tsSz);
    end
    [p, t] = getInputTarget(trFileset); 
    inputByPerson = p(1:fullTrainRec,:); targetByPerson = t(1:fullTrainRec,:);
    for i=fullTrainRec+1:fullTrainRec:size(p,1)
        pTmp = p(i:i+fullTrainRec-1,:); tTmp = t(i:i+fullTrainRec-1,:);
        inputByPerson = cat(3, inputByPerson, pTmp);  targetByPerson = cat(3, targetByPerson, tTmp);
    end
    save('trainReplicatedRecords','p','t','inputByPerson','targetByPerson'); clear inputByPerson p pTmp targetByPerson t tTmp
    [p, t] = getInputTarget(tsFileset);
    inputByPerson = p(1:fullTestRec,:); targetByPerson = t(1:fullTestRec,:);
    for i=fullTestRec+1:fullTestRec:size(p,1)
        pTmp = p(i:i+fullTestRec-1,:); tTmp = t(i:i+fullTestRec-1,:);
        inputByPerson = cat(3, inputByPerson, pTmp);  targetByPerson = cat(3, targetByPerson, tTmp);
    end
    save('testReplicatedRecords','p','t','inputByPerson','targetByPerson')
end
function [fileset, item] = padding(i, FaceDataset, fileset, fullSize, item, sz)
%     sz = size(fileset,1);
    rec = sz;
    if(sz < fullSize)
        remain = fullSize - sz; val = 1;
        if(remain < sz)
            for j=item:item+remain-1
                fileset(item,:) = sprintf('bioid_%04d.pts', FaceDataset.(sprintf('d%d',i))(val));
                item = item + 1; val = val + 1;
            end
        elseif(remain > sz)
            while(rec < fullSize)
                if(val > sz)
                    val = 1;
                end
                fileset(item,:) = sprintf('bioid_%04d.pts', FaceDataset.(sprintf('d%d',i))(val));
                item = item + 1; val = val + 1; rec = rec + 1;
            end
        end
    end
end
function [p, t] = getInputTarget(fileset)
    for variable=1:size(fileset,1)  
        [p(variable,:),t(variable,:)] = getFileData(fileset(variable,:)); %row wise
    end
    p = RTSInvariant(p);
end