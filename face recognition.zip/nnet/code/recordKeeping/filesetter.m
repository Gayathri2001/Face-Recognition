function fileset = filesetter(FaceDataset, variable)
% fileset = zeros(1,sum(variable(:)));
listSize = 1;
for i=1:size(variable,2)
    for j=1:variable(i)
        fileset(listSize,:) = sprintf('bioid_%04d.pts', FaceDataset.(sprintf('d%d',i))(j));
        listSize = listSize + 1;
    end
end