function replicatedRecords()
FaceDataset = FaceDatabase;
totalSets = FaceDataset.fields;
item = 1;
p = zeros(3450,40); t = zeros(3450,23); 
for i=1:totalSets
    sz =size(FaceDataset.(sprintf('d%1.0f',i)),2);
    rec = sz;
    for j=1:sz
        fileset(item,:) = sprintf('bioid_%04d.pts', FaceDataset.(sprintf('d%d',i))(j));
        item = item + 1;
    end
    if(sz < 150)
        remain = 150 - sz; val = 1;
        if(remain < sz)
            for j=item:item+remain-1
                fileset(item,:) = sprintf('bioid_%04d.pts', FaceDataset.(sprintf('d%d',i))(val));
                item = item + 1; val = val + 1;
            end
        elseif(remain > sz)
            while(rec < 150)
                if(val > sz)
                    val = 1;
                end
                fileset(item,:) = sprintf('bioid_%04d.pts', FaceDataset.(sprintf('d%d',i))(val));
                item = item + 1; val = val + 1; rec = rec + 1;
            end
        end
    end
end
for variable=1:size(fileset,1)  
    [p(variable,:),t(variable,:)] = getFileData(fileset(variable,:)); %row wise
end
    trainRec = floor(60/100 *size(p,1)); testRec = floor(40/100 *size(p,1));
    p = RTSInvariant(p);
    p1 = p; t1 = t; clear p t
    p(1:trainRec,:) = p1(1:trainRec,:); t(1:trainRec,:) = t1(1:trainRec,:);
    save('trainReplicatedRecords','p','t'); clear p t
    p(1:testRec,:) = p1(trainRec:end-1,:); t(1:testRec,:) = t1(trainRec:end-1,:);
    save('testReplicatedRecords','p','t')
