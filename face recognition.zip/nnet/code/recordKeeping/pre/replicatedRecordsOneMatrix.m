function replicatedRecords()
    % clear,clc, close all
    % directory =cd(fileparts(mfilename('fullpath')));
    % % DataBaseAll
    % cd('../../../')
    % paths
    % cd(sprintf('%s',directory))
    FaceDataset = FaceDatabase;
    totalSets = FaceDataset.fields;
    trainRec = zeros(1,totalSets);
    testRec = zeros(1,totalSets);
    fullTrainRec = 60/100 * FaceDataset.maxRec; 
    fullTestRec = 40/100 * FaceDataset.maxRec;
    for i=1:totalSets
        total = size(FaceDataset.(sprintf('d%d',i)),2);
        trainRec(i) = floor(60/100 *total);
       testRec(i) = total - trainRec(i);
    end
    trItem = 1; tsItem = 1;
    for i=1:totalSets
        trSz = trainRec(i); tsSz = testRec(i);
        for j=1:trSz
            trFileset(trItem,:) = sprintf('bioid_%04d.pts', FaceDataset.(sprintf('d%d',i))(j));
            trItem = trItem + 1;
        end
        for j=1:tsSz
            tsFileset(tsItem,:) = sprintf('bioid_%04d.pts', FaceDataset.(sprintf('d%d',i))(j));
            tsItem = tsItem + 1;
        end
        trFileset = padding(i, FaceDataset, trFileset, fullTrainRec, trSz);
        tsFileset = padding(i, FaceDataset, tsFileset, fullTestRec, tsSz);
    end
    [p, t] = getInputTarget(trFileset); 
    save('trainReplicatedRecords','p','t'); clear p t
    [p, t] = getInputTarget(tsFileset);
    save('testReplicatedRecords','p','t')
end
function [fileset] = padding(i, FaceDataset, fileset, fullSize, sz)
%     sz = size(fileset,1);
    item = sz + 1;
    rec = sz;
    if(sz < fullSize)
        remain = fullSize - sz; val = 1;
        if(remain < sz)
            for j=item:item+remain-1
                fileset(item,:) = sprintf('bioid_%04d.pts', FaceDataset.(sprintf('d%d',i))(val));
                item = item + 1; val = val + 1;
            end
        elseif(remain > sz)
            while(rec < fullSize)
                if(val > sz)
                    val = 1;
                end
                fileset(item,:) = sprintf('bioid_%04d.pts', FaceDataset.(sprintf('d%d',i))(val));
                item = item + 1; val = val + 1; rec = rec + 1;
            end
        end
    end
end
function [p, t] = getInputTarget(fileset)
    for variable=1:size(fileset,1)  
        [p(variable,:),t(variable,:)] = getFileData(fileset(variable,:)); %row wise
    end
    p = RTSInvariant(p);
end