clear,clc %, close all
cd(fileparts(mfilename('fullpath')));
%%% Input Vector and target vector
%     DataBaseNormalized
    DataBaseAll
    p = round(p);
%%% Record Selection
    t =randperm(1520);
    variable = t(1,abs(round(rand(1,1)*6)));
%%% (x,y) Selection from the Record
    x = p(variable,1:2:40); y = p(variable,2:2:40);
    clear t

%% Rotation
%%% XY axis Rotation
%%% Centralization to the origin for rotation
    xPrev = x(15); yPrev = y(15); 
    x  = x - xPrev; y  = y - yPrev;
%%% Initailization of variables
    %   1 = right eye pupil
    %   2 = left eye pupil
    width = x(1) - x(2);
    height = y(1) -y(2);
    theta = atan2(height,width);
    rot = [cos(theta) -sin(theta); sin(theta) cos(theta)];
%%% Step wise all the (x,y) are rotated
    for i = 1:20
    %   then mult each of the 20 [x;y] points by rot 
    %   after subtracting [xl;yl]
      t = rot * [x(i) y(i)]';
      x2(i) = t(1); y2(i) = t(2);
    end
%% GUI
figure
imshow(imread(sprintf('../../../res/database/Face Database/BioID-FaceDatabase-V1.2/BioID_%04d.pgm',variable)));
hold on
plot(x  + xPrev,y + yPrev,'.r')
% plot(line(x([ 15 18 19 20 ])+xPrev,y([ 15 18 19 20 ])+yPrev));
plot(x2 + xPrev,y + yPrev,'.b')
% text(0.7753, 0.9217, ... 
title([sprintf('BioId %d.pgm,  ',variable), ...
    '{\fontsize{8}\color{red}   Original,}', ...
    '\fontsize{10}\color{blue}  Rotated,  '])
xlabel(['\fontsize{10}\color{black} rotation Matrix =  ', ...
    sprintf('%1.4f,  ',rot(1)),     sprintf('%1.4f,\n  ',rot(2)), ...
    sprintf('%31.4f,  ',rot(3)),     sprintf('%1.4f\n  ',rot(4)), ...
    '\fontsize{10}\color{black} Theta(Angle to change) =  ', sprintf('%1.4f',theta)])
