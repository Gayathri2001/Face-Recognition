cd(fileparts(mfilename('fullpath')));
path(pwd, path);
cd([pwd '\..\recordKeeping'])
DataBaseAll
t =randperm(1520);
variable = t(1,abs(round(rand(1,1)*6)));
%%% (x,y) Selection from the Record
x = p(variable,1:2:40); y = p(variable,2:2:40);
x = x - min(x); y = y - min(y); 
plot(x,y,'.r'); hold on; FormattedPlot(x,y,'r')
x = x * 50/max(x); y = y * 50/max(y);
plot(x,y,'.g'); hold on; FormattedPlot(x,y,'g')


title([sprintf('BioId %d.pgm,  ',variable), ...
    '{\fontsize{8}\color{red}   Original,}', ...
    '{\fontsize{8}\color{green}   Sir,}', ...
    '\fontsize{10}\color{blue}  mine,  '])
% y = 130, x = 115
% formula 
% P_j(x) / Max X * 300 % P_j(x) * 300 / Max X
