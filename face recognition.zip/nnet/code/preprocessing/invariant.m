% clear,clc, close all
cd(fileparts(mfilename('fullpath')));
path(pwd, path);
cd([pwd '\..\recordKeeping'])
p = ones(1521,40); 
DataBaseAll
totalRecords = size(p,1);
cd('../../../res/database/Face Database/BioID-FaceDatabase-V1.2/')
    t =randperm(totalRecords);
    variable = t(1,abs(round(rand(1,1)*6)));
    %% (x,y) Selection from the Record
    x = p(variable,1:2:40); y = p(variable,2:2:40);
    % p = round(p);
    % for i=10:30 %1136:1147
    %     i = 98; %18:26
        pic = imread(sprintf('BioID_%04d.pgm',variable ));
        figure, imshow(pic);
        title(sprintf('BioID %04d',variable ));
        hold on
        x = p(variable ,1:2:40);    y = p(variable ,2:2:40);
        plot(x,y,'r.');
        [ ul, ur, bl, br, cent, m, maxX, maxY ] = FormattedPlot(x,y,'r','y');
        x  = x - cent(1); y  = y - cent(2);
        angT = (90 - atand(abs(m)))* sign(m); 
        for i = 1:20
          t = [cosd(angT) -sind(angT); sind(angT) cosd(angT)] * [x(i) y(i)]';
          x1(i) = t(1); y1(i) = t(2);
        end
    % end
    x1 = x1 + cent(1);
    y1 = y1 + cent(2);
    plot(x1 ,y1,'.b'); FormattedPlot(x1,y1,'b');
    %% Translate
        x1 = x1 - min(x1);
        y1 = y1 - min(y1);
        plot(x1 ,y1,'.g'); FormattedPlot(x1,y1,'g');
    %% Scale
        x1 = x1 * 50/max(x1); y1 = y1 * 50/max(y1);
        plot(x1,y1,'.k'); hold on; FormattedPlot(x1,y1,'k')

    title([sprintf('BioId %d.pgm,  ',variable), ...
        '{\fontsize{8}\color{red}   Original,}', ...
        '\fontsize{10}\color{blue}  Rotated,  '])
    xlabel(['\fontsize{10}\color{black} Slope =  ', sprintf('%1.0f,  ',m), ...
        '\fontsize{10}\color{black} Theta(Angle to change) =  ', sprintf('%1.4f',angT)])
% hullname := 
% hullname := [p9, p5, p6, p8, p14, p4, p20]
% hullname := [p9, p5, p6, p7, p8, p14, p20]
