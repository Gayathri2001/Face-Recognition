function [ul, ur, bl, br, cent, m, maxX, maxY ] = squareCenterSlope(x1,y1)
maple('interface(warnlevel=0);');
maple('with(geometry):');
maple('_EnvHorizontalName := x: _EnvVerticalName := y:');
%% Square center
    maple(sprintf('point(A,%d,%d),point(B,%d,%d):',x1(6),y1(6),x1(7),y1(7)));
    maple('line(lu,[A,B]):'); % A is the horizontal axis and B is vertical axis
%     lineEq =maple('Equation(lu,[x,y]):');
    maple(sprintf('point(bot,%d,%d):',x1(20),y1(20)));
    maple('ParallelLine(lb, bot, lu):'); % p is point, l is line, lp is the new line
    maple(sprintf('point(rig,%d,%d):',x1(9),y1(9)));
    maple('PerpendicularLine(lrp, rig, lu):');
    maple(sprintf('point(lef,%d,%d):',x1(14),y1(14)));
    maple('PerpendicularLine(llp, lef, lu):');
    maple('intersection(ul, lu, llp):'); % intersection b/w two lines 
    maple('intersection(ur, lu, lrp):'); 
    maple('intersection(bl, lb, llp):'); 
    maple('intersection(br, lb, lrp):'); 
    ul = str2num(maple('coordinates(ul);'));
    ur = str2num(maple('coordinates(ur);'));
    bl = str2num(maple('coordinates(bl);'));
    br = str2num(maple('coordinates(br);'));
    maple('line(dl,[ul,br]):'); maple('line(dr,[ur,bl]):');
    maple('intersection(cent, dl, dr):');
%%% Center point
    cent = str2num(maple('coordinates(cent);'));
    %%% Slope
        maple('with(LinearAlgebra):');
        maple('arg1 := HorizontalCoord(ul): arg2 := HorizontalCoord(bl): if(evalb(arg1 = arg2)) then m:=0; else m := evalf(slope(llp)): end if:');
        m = str2num(maple('m;'));
    %%% Max (x,y)    
        maxX = maple('distance(ul,ur);');
        maxY = maple('distance(ul,bl);');
