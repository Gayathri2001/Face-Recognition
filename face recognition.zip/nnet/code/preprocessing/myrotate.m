clear,clc
% close all
cd(fileparts(mfilename('fullpath')));
DataBaseAll
i = 18;
x = p(i,1:2:40);    y = p(i,2:2:40);

lx  = x([ 15 18 19 20 ])
ly  = y([ 15 18 19 20 ])
[m c] = polyfit(lx,ly,1)

ang = 90 - atand(m(1)) ;


x1  = x - x(15);
y1  = y - y(15);

sa  = sind(ang);
ca  = cosd(ang);

for i = 1:20
  t = [ ca  -1 * sa ; sa ca] * double([x1(i) y1(i)])';
  x2(i) = t(1)  ;
  y2(i) = t(2)  ;
end
figure, plot(x1,y1,'.r')
hold on 
plot(x2,y2,'.b')
text(0.8519, 0.9374, ['{\fontsize{8}\color{red}Original}', sprintf('\n'), ...
               '\fontsize{10}\color{blue}Rotated'],'Units','normalized');

