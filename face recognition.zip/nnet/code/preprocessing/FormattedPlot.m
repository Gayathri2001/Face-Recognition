function [ul, ur, bl, br, cent, m, maxX, maxY ] = FormattedPlot(x1,y1,c,y)
% this is the file for getting the euation of a line from two points
maple('with(geometry):');
maple('_EnvHorizontalName := x: _EnvVerticalName := y:');
%% Square center
    %maple('point(A,x1(7),y1(6)),point(B,x1(8),y1(5)):')
    maple(sprintf('point(A,%d,%d),point(B,%d,%d):',x1(6),y1(6),x1(7),y1(7)));
    maple('line(lu,[A,B]):'); % A is the horizontal axis and B is vertical axis
    lineEq =maple('Equation(lu,[x,y]):');
    maple(sprintf('point(bot,%d,%d):',x1(20),y1(20)));
    maple('ParallelLine(lb, bot, lu):'); % p is point, l is line, lp is the new line
    %maple('detail(lb);')
    maple(sprintf('point(rig,%d,%d):',x1(9),y1(9)));
    maple('PerpendicularLine(lrp, rig, lu):');
    %maple('detail(lrp);')
    maple(sprintf('point(lef,%d,%d):',x1(14),y1(14)));
    maple('PerpendicularLine(llp, lef, lu):');
    %maple('detail(llp);')
    maple('intersection(ul, lu, llp):'); % intersection b/w two lines 
    maple('intersection(ur, lu, lrp):'); 
    maple('intersection(bl, lb, llp):'); 
    maple('intersection(br, lb, lrp):'); 
    ul = str2num(maple('coordinates(ul);'));
    ur = str2num(maple('coordinates(ur);'));
    bl = str2num(maple('coordinates(bl);'));
    br = str2num(maple('coordinates(br);'));
    hold on
    plot([ul(1) ur(1)],[ul(2) ur(2)],c); 
    plot([ur(1) br(1)],[ur(2) br(2)],c);
    plot([br(1) bl(1)],[br(2) bl(2)],c);
    plot([bl(1) ul(1)],[bl(2) ul(2)],c);
    maple('line(dl,[ul,br]):'); maple('line(dr,[ur,bl]):');
    maple('intersection(cent, dl, dr):');
%%% Center point
    cent = str2num(maple('coordinates(cent);'));
    plot(cent(1), cent(2),sprintf('s%c',c));
    if nargin > 3
    %%% Slope
        maple('with(LinearAlgebra):');
        maple('arg1 := HorizontalCoord(ul): arg2 := HorizontalCoord(bl): if(evalb(arg1 = arg2)) then m:=0; else m := evalf(slope(llp)): end if:');
        m = str2num(maple('m;'));
    %%% Max (x,y)    
        maxX = maple('distance(ul,ur);');
        maxY = maple('distance(ul,bl);');
    end
%% Centerid
    % maple(sprintf('point(p1,%d,%d),point(p2,%d,%d):',x1(1),y1(1),x1(2),y1(2)));
    % maple(sprintf('point(p3,%d,%d),point(p4,%d,%d):',x1(3),y1(3),x1(4),y1(4)));
    % maple(sprintf('point(p5,%d,%d),point(p6,%d,%d):',x1(5),y1(5),x1(6),y1(6)));
    % maple(sprintf('point(p7,%d,%d),point(p8,%d,%d):',x1(7),y1(7),x1(8),y1(8)));
    % maple(sprintf('point(p9,%d,%d),point(p10,%d,%d):',x1(9),y1(9),x1(10),y1(10)));
    % maple(sprintf('point(p11,%d,%d),point(p12,%d,%d):',x1(11),y1(11),x1(12),y1(12)));
    % maple(sprintf('point(p13,%d,%d),point(p14,%d,%d):',x1(13),y1(13),x1(14),y1(14)));
    % maple(sprintf('point(p15,%d,%d),point(p16,%d,%d):',x1(15),y1(15),x1(16),y1(16)));
    % maple(sprintf('point(p17,%d,%d),point(p18,%d,%d):',x1(17),y1(17),x1(18),y1(18)));
    % maple(sprintf('point(p19,%d,%d),point(p20,%d,%d):',x1(19),y1(19),x1(20),y1(20)));
    % maple('ps := [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20]')
    % maple('centroid(G,ps);') % center of all the 20 points
    % maple('detail(G);') 
    % centerPoint = str2num(maple('coordinates(G);'));
    % plot(centerPoint(1),centerPoint(2),'db')
%%% polygon
    % maple('hullname:=convexhull({ p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20});')
    % centerPoly = str2num(maple('coordinates(centroid(G,hullname));'));
    % plot(centerPoly(1),centerPoly(2),'hk')
%%% Other Slope
    % maple('with(stats):')
    % maple(sprintf('eqn :=fit[leastsquare[[x,y]]]([[%d,%d,%d],[%d,%d,%d]]);',x1([18 19 20]),y1([18 19 20])))
    % maple('line(regL, eqn, [x,y])')
    % maple('m1 := slope(regL);')
%%
% maple('RegularPolygon(p, 9, cen, rad)')
% maple('slope(l);')
% maple('point(A,1,8), point(B,-1,2):')
% maple('FindAngle(l1, l2);')
% maple('SpiralRotation(Q, P, O, theta, dir, k)') % rotation
% maple('homology(Q, P, O, theta, dir, k)')       % rotation
% maple('StretchRotation(Q, P, O, theta, dir, k)')% rotation