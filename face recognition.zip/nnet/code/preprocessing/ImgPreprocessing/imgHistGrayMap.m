function [in,out,pf, tf] = ...
            imgHistGrayResizeMap(filename)
cd e:\thesis\
paths
str = strcat(res,filename); %'fozia.jpg'); %
in = imread(str);
out(:,:,1) = histeq(in(:,:,1));
out(:,:,2) = histeq(in(:,:,2));
out(:,:,3) = histeq(in(:,:,3));
out = rgb2gray(out);
sz = round(size(out)/6);
stdSz = [51 38];
clear str res netCodeDir netDir netFormDir netModelDir imgCodeDir imgModelDir imgFormDir
%if (sz(1)*sz(2) < stdSz(1)*stdSz(2))
%    sz = round(size(out)/2);
%    out = imresize(im2double(out),sz);
%elseif size(out) < stdSz
%    out = im2double(out);
%elseif (size(out)/6) > stdSz
%    out = imresize(im2double(out),stdSz);
%else
%    out = imresize(im2double(out),sz);
%end
out = imresize(im2double(out),stdSz);
pf = mapminmax(out);
tf = mapminmax(out);
%netsz = size(pf);
%net = newff(minmax(pf),[51,51],{'tansig','purelin'},'trainscg');
%net.trainParam.epochs=300;
%net.trainParam.show=NaN;
%net.trainParam.goal=1e-5;
%[net,tr] = train(net,pf,tf);
%a = sim(net,pf);
%imshow(a)