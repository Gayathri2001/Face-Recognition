function [pf, tf] = imgNN(f)
if nargin < 1
    str = 'E:\thesis\res\adeel.jpg';
end
%f = rgb2gray(imread(str));
%f = rgb2gray(f);
%f = imresize(im2double(rgb2gray(f)),[77 57]); % div 4
%f = imresize(im2double(rgb2gray(f)),[61 46]);  % div 5
sz = round(size(f)/6);
stdSz = [51 38];
if size(f) < stdSz
    f = im2double(f); 
elseif (size(f)/6) > stdSz
    f = imresize(im2double(f),stdSz); 
else
    f = imresize(im2double(f),sz);
end
pf = mapminmax(f);
tf = mapminmax(f);