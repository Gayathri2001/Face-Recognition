clear,clc %, close all
cd(fileparts(mfilename('fullpath')));
%%% Input Vector and target vector
%     DataBaseNormalized
    path(pwd, path);
    cd([pwd '\..\recordKeeping'])
    DataBaseAll
    p = round(p);
%%% Record Selection
    variable  = 201;
%     t =randperm(1520);
%     variable = t(1,abs(round(rand(1,1)*6)));
%%% (x,y) Selection from the Record
    x = p(variable,1:2:40); y = p(variable,2:2:40);
    clear t

%% Rotation
%%% XY axis Rotation
%%% Centralization to the origin for rotation
    xPrev = x(15); yPrev = y(15); 
    x  = x - xPrev; y  = y - yPrev;
%%% Regression to a straight line
%     % 15 = tip of nose
    % 18 = centre point on outer edge of upper lip
    % 19 = centre point on outer edge of lower lip
    % 20 = tip of chin 
    m = polyfit(x([18 19 20]),y([18 19 20]),1);
%%% Theta
    ang = (90 - atand(abs(m(1)))) * sign(m(1));
%%% Step wise all the (x,y) are rotated
    for i = 1:20
      t = [cosd(ang) -sind(ang); sind(ang) cosd(ang)] * [x(i) y(i)]';
      x2(i) = t(1); y2(i) = t(2);
    end
%% GUI
figure
imshow(imread(sprintf('../../../res/database/Face Database/BioID-FaceDatabase-V1.2/BioID_%04d.pgm',variable)));
hold on
plot(x  + xPrev,y + yPrev,'.r')
plot(line(x([18 19 20])+xPrev,y([18 19 20])+yPrev));
plot(line(x2([18 19 20])+xPrev,y2([18 19 20])+yPrev),'r');
plot(x2 + xPrev,y2 + yPrev,'.b')
% text(0.7753, 0.9217, ... 
title([sprintf('BioId %d.pgm,  ',variable), ...
    '{\fontsize{8}\color{red}   Original,}', ...
    '\fontsize{10}\color{blue}  Rotated,  '])
xlabel(['\fontsize{10}\color{black} Slope =  ', sprintf('%1.0f,  ',m(1)), ...
    '\fontsize{10}\color{black} Theta(Angle to change) =  ', sprintf('%1.4f',ang)])
