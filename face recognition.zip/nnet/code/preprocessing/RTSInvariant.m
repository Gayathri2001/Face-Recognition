function p =RTSInvariant(p)
totalRecords = size(p,1);
for variable=1:totalRecords  %1521
    x = p(variable,1:2:40); y = p(variable,2:2:40);
        x = p(variable ,1:2:40);    y = p(variable ,2:2:40);
        [ ul, ur, bl, br, cent, m, maxX, maxY ] = squareCenterSlope(x,y);
        x  = x - cent(1); y  = y - cent(2);
        angT = (90 - atand(abs(m)))* sign(m); 
        for i = 1:20
          t = [cosd(angT) -sind(angT); sind(angT) cosd(angT)] * [x(i) y(i)]';
          x1(i) = t(1); y1(i) = t(2);
        end
    %% Translate and then scale
        x1 = ((x1 + cent(1)) - min(x1)) * 1/max(x1);
        y1 = ((y1 + cent(2)) - min(y1)) * 1/max(y1);
    p(variable,1:2:40) = x1; p(variable,2:2:40) = y1;
end
