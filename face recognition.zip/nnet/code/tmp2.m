function trainBPMatlab()
%% ==Step_0==Initialization=================================
clc,clear
%%% Opening of the Input / Target Files
%tic, t = toc
%%
disp('Loading the input vector x and target vectors')
data
disp('Loading of input vector x and target vectors done')
WHEN USING THE NNTOOLBOX USE p FOR TRAINING INPUT 
AND t FOR TRAINING TARGET
DON'T REUSE THE SAME LABEL FOR DIFFERENT ARRAYS
READ p00,t00
CHECK THE DIMENSIONS OF p00,t00 
USE t00 TO FIND THE PRIOR PROBABILITIES OF THE 23 CLASSES
SINCE THE PRIORS ARE VERY NONUNIFORM, ADD DUPLICATES 
SO THAT ALL CLASSES ARE THE SAME SIZE: p0 AND t0
YOU WILL THEN HAVE N0 = 23*150 = 3450 INSTEAD OF N00 =1520
CHECK THE DIMENSIONS OF p0,t0
USE PRESTD (OR ZSCORE?) TO STANDARDIZE p0 TO HAVE 0 MEAN 
AND UNIT STANDARD DEVIATION: p1
CHECK THE MEAN AND STANDARD DEVIATION OF p1
CONVERT t0 TO HAVE 1-OF-23 BINARY CODING: t1
USE t1 TO CREATE A CLASS LABEL VECTOR lab1 OF LENGTH 3450 
CONTAINING THE CLASS INDICES 1:23
STORE p1,t1,lab1 FOR SAFEKEEPING
INITIALIZE THE RNG SO YOU CAN REPEAT THE RUNS
RANDOMIZE THE ORDER OF p1,T1,lab1 AND TRANSPOSE SO THAT
[I Np] = size(p) % = [ 40 3450]
[O Nt] = size(t) % = [ 23 3450]
[one Nl ] = size(lab) % = [ 1 3450]
VERIFY THE DIMENSIONS ARE CORRECT THEN USE N = 3450
trainRecords = size(x,1);
r = randperm(trainRecords);
x1 = x; t1 = t;
for i=1:trainRecords
x(i,:) = x1(r(i),:);
t(i,:) = t1(r(i),:); %tA
end
clear x1 t1 trainRecords
CLEAR UNNECESSARY VARIABLES
WHAT IS THE MSE IF YOU USE THE 
NAIVE MODEL
y00 = mean(t')';
MSE00 = 
USE lab TO FIND THE CORRESPONDING 
CLASS CONDITIONAL ERROR RATES AND
THE MIXTURE ERROR RATE (TOTAL NUMBER 
OF MISCLASIFICATIONS /N)
WHAT IS THE MSE IS IF YOU USE THE 
LINEAR MODEL
y0 = B*[ones(1,N);p];
MSE0 =
R02 = 1-MSE0/MSE00
USE lab TO FIND THE CORRESPONDING 
CLASS CONDITIONAL PER CENT ERROR RATES, 
AND THE CLASS MIXTURE PER CENT ERROR RATE 
CLASSERR0 = 100*(...
MIXTERR0 = 100*(...
FIND THE SUMMARY STATISTICS OF CLASSERR0
MINERR0 =
MEDIANERR0 =
MEANERR0 = 
STDERR0 =
MAXERR0 =
USE NEWFF TO CHECK THE LINEAR RESULTS
MSEgoal = MSE00/100
epochmax = 3000
net = newff(minmax(p),O); % O = 23, No hiddenlayer H = 0
net.trainParam.epochs = epochmax;
net.trainParam.goal = MSEgoal;
tic
[net tr Y E] = train(net,p,t); % Using defaults (see help trainlm)
% SEE help trainlm TO SEE WHAT INFO IS IN tr
toc
Nepochs = tr.epochs(end)
y1 = sim(net,p,t);
e1 = t-y1;
MSE1 =
R12 = 1-MSE1/MSE00
CLASSERR1 =
MIXTERR1 = 
MINERR1 =
MEDIANERR1 =
MEANERR1 = 
STDERR1 =
MAXERR1 =
checky = max(max(abs(y1-Y)))
checke = max(max(abs(e1-E))
checkmse1 = max(abs(MSE1-tr.perf(end)))
checkmse 2 = max(abs(MSE1-MSE0))
COMPARE THE REST OF THE 1 AND 0 RESULTS
REPEAT FOR THE LOGISTIC CLASSIFIER
net = newff(minmax(p),O,{'logsig'}); % No hiddenlayer H = 0
..
y2 =
...
YOU COULD ALSO USE FUNCTION glmfit TO GET A LOGISTIC 
CLASSIFIER. HOWEVER, I HAVE NEVER USED IT.
NOW YOU HAVE A BASELINE TO JUDGE YOUR
I-H-O HIDDEN LAYER RESULTS.
% ----------------------------------------------------------
%%% Enter the Architecture detail
disp('Enter the Architecture detail');
e = 0.05; % error limit
SEE ABOVE
n = size(x,2); %INPUT
% p = input('Enter the number of Hidden neurons : ');
% p = 41; %ceil(trainRecords*e); % HIDDEN Because W/p = e and 60% is 46, 100% is 
76
FORGET THAT. THE BEST ESTIMATE FOR H IS OBTAINED BY LOOKING
AT THE RATIO OF EQUATIONS TO UNKNOWNS. SEE MY POSTS 
REGARDING
r = Neq/Nw , (~2 <= r <= ~32)
r=1 CORRESPONDS TO THE LINEAR AND LOGISTIC MODELS. 
WITH A HIDDEN LAYER, H HAS TO BE FOUND BY TRIAL AND ERROR. 
IF MSE0 LOOKS GOOD, TRY r = 2, 4, 8, 16, 32 ... UNTIL BRACKETED
THEN REFINE USING BINARY OR EXHAUSTIVE SEARCH
IF MSE0 LOOKS BAD, START A BINARY SEARCH WITH r =8 (SOME 
PEOPLE LIKE 5, SOME LIKE 10)
%%%%%%%%%%%
m = size(t,2); % OUTPUT
% alpha = input('Enter the Learning rate : ');
LEARNING RATE IS CALLED eta
% alp = input('Enter the Momentum rate : ');
MOMENTUM COEFFICIENT IS CALLED alpha

% ----------------------------------------------------------- 
net = newff(minmax(x'),[41 23],{'tansig','purelin'},'traingdm');
RECONSIDER H = 41
USE logsig FOR UNIPOLAR BINARY OUTPUT
SEE help traingdm TO FIND OUT WHAT THE DEFAULT 
PARAMETER SETTINGS ARE
IF YOU USE THE DEFAULTS, YOU CAN DELETE THOSE 
ASSIGNMENT COMMANDS
net.trainParam.epochs=1900;
BASE ON HOW LONG IT TOOK TO TRAIN THE 
LINEAR AND LOGISTIC MODELS
net.trainParam.goal=5e-2;
I USE MSE00/100 (YIELDS R^2 = 0.99)
net.trainParam.lr=0.01; %0.05
ALWAYS START WITH THE DEFAULTS
net.trainParam.show=100;
ALWAYS START WITH THE DEFAULTS OR LOWER
net.trainParam.mc =0.9; %0.9
net.performFcn = 'mse';
ALWAYS START WITH THE DEFAULTS
clc
x = transpose(x);t = transpose(t); whos x t
[net,tr] = train(net,x,t);
% a = sim(net,x)
end %% End of Function / File
%{
DON'T FORGET: YOUR ULTIMATE GOAL IS REALLY
LOW MEANERR AND MAXERR 
FOR EXAMPLE, IF YOU HAVE A MIXTERR = 4% 
BUT THE ERRORS ON PERSONS 4 AND 19 ARE 
100%, THEN THAT IS NOT ACCEPTABLE. 
THAT IS WHY (SEE MY THREAD ON UNBALANCED BIOID DATA 
IN CSSM) I HAD YOU EVEN OUT THE PRIORS.
Good Luck,
Greg
%}