function [v,v0,w,w0] = trainBackPropagationNet(v,v0,w,w0)
%Create an back propagation neural network
%+++++++++++++++++++Formula formatted text in formulas++++++++++++
% Legent of Formatted Formula text 
%   _ (underscore) means Subscript
%   ^ (power)      means Superscript
%   () parenthesis is used for grouping, (openoffice uses {} instead).
%+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%%% Nomenclature
% x     Input training vector:
%           x = (x1, ..... xi, ..... xn)
% t     Output training vector:
%           t = (t1, ..... tk, ..... tm)
% d     Portion of error correction weight adjustment for w_(jk) that is 
%       due to an error at the output unit Y_k; also, the information about
%       the error at unit Y_k that is propagated back to the hidden units 
%       that feed into unit Y_k
% dj    Portion of error correction weight adjustment for v_(ij) that is 
%       due to the backpropagation of error information from the output 
%       layer to the hidden unit Z_j.
% alpha Learning rate
% X_i   Input unit i:
%       For an input unit; the input signal and output signal are the same,
%       namely, x_i.
% v0_j  Bais on the hidden unit j.
% Z_j   Hidden init j:
%       The net input to Z_j is denoted zin_j:
%           zin_j = v0_j + sum(x_i*v_(ij)).
%       The output signal (activation) of Zj is denoted zj:
%           z_j = f(zin_j).
% w0_k  Bais on output unit k.
% Y_k   Output unit k.
%       The net input to Yk is denoted y_ink:
%           yin_k = w0_k + sum(z_j*w_(jk))
%       The output signal (activation) of Yk is denoted yk:
%           y_k = f(yin_k).
%%% Activation function:
%           f(x) = 2/(1 + exp(-x)) -1
%       with its derivative 
%           f'(x) = 1/2*(1 + f(x))*(1-f(x))
%
%%% Training Algorithm
% Step 0.   Initialize Weights
%           (set to small random values (in the range -0.5 and 0.5, 
%           according to Nguyen-Widrow Initialization)
% Step 1.   While stopping condition is false, do Steps 2-9
%           Step 2.     For each training pair, do Steps 3-8
%%                       Feedforward:
%                       Step 3.     Each input unit (Xi, i = 1, ...,n)
%                                   receives input signal xi and broadcasts
%                                   this signal to all units in the layer
%                                   above (the hidden units).
%                       Step 4.     Each hidden unit (Zj, j=1, ...,p) sums
%                                   its weighted input signals,
%                                     zin_j = v0_j + ?_(i=1)^n x_i v_(ij)
%                                   applies its activation function to
%                                   compute its output signal,
%                                     z_j = f(zin_j),
%                                   and sends this signal to all units in
%                                   the layer above (output units).
%                       Step 5.     Each output unit (Y_k,k=1,...,m) sums
%                                   its weights input signals,
%                                     yin_k = w0_k + ?_(j=1)^p z_j w_(jk)
%                                   and applies its activation fuction to
%                                   compute its output signal,
%                                     y_k = f(yin_k).
%%                       BackPropagation of error:
%                       Step 6.     Each output unit (Y_k,k=1,...,m)
%                                   receives a target pattern corresponding
%                                   to the input training pattern, computes
%                                   its error information term,
%                                     d_k  =(t_k   - y_k)  f'(yin_k),
%                                   calculates its weight correction term
%                                   (used to update w_(jk) later),
%                                     chw_(jk) = alpha d_k z_j,
%                                   calculates its bais correction term
%                                   (used to update w0_k later),
%                                     chw0_k = alpha d_k,
%                                   and sends d_k to units in the layer
%                                   below.
%                       Step 7.     Each hidden unit (Z_j,j=1,...,p)
%                                   sums its delta inputs (from units in
%                                   the layer above),
%                                     din_j = ?_(k=1)^m d_k w_(jk),
%                                   multiplies by the derivative of its
%                                   activation function to calculate its 
%                                   error information term,
%                                     d_j  =din_j  f' (zin_j),
%                                   calculates its weight correction term
%                                   (used to update v_(ij) later),
%                                     chv_(ij) = alpha d_j x_i,
%                                   calculates its bais correction term
%                                   (used to update v0_j later),
%                                     chv0_j = alpha d_j.
%%                                   Update weights and baises:
%                       Step 8.     Each output unit (Y_k,k=1,...,m)
%                                   updates its bais and weights
%                                   (j=0,...,p):
%                                      w_(jk) (new) = w_(jk) (old) + chw_(jk),
%                                   Each hidden unit (Z_j,j=1,...,p)
%                                   updates its bais and weights
%                                   (i=0,...,n):
%                                      v_(ij) (new) = v_(ij) (old) + chv_(ij),
%           Step 9.     Test stopping condition.

%%  ==Step_0==Initialization=================================
clc, clear
%%% Enter the Architecture detail
    disp('Enter the Architecture detail');
    n = 40;  %INPUT      
    p = 2; %  HIDDEN     Because W/p = e and 60% is 46, 100% is 76
    m = 5; % OUTPUT
    alpha = input('Enter the Learning rate :  ');
%     alp = input('Enter the Momentum rate :  ');
%  -----------------------------------------------------------
%%% Opening of the Input / Target Files
%tic, t = toc
    cd(getenv('thesis'))
    paths
    disp('Loading the input vector x and target vectors')
    cd(strcat(getenv('thesis'),'\res\database\Face Database\ExtraFeatures\points_20'));
    FaceDataset = FaceDatabase;
    train = D6040(FaceDataset);
    fileset = filesetter(FaceDataset, train);
    trainRecords = sum(train(:));
    x = zeros(trainRecords,n); x = single(x);
    t1 = false(trainRecords,m);
    for var=1:trainRecords  
        [x1(var,:),t1(var,:)] = getFileData(fileset(var,:)); %row wise
    end
    r = randperm(trainRecords);
    for i=1:trainRecords
        x(i,:) = x1(r(i),:);
        tA(i,:) = t1(r(i),:);
    end
    [t,TS] = mapminmax(double(tA),-.9,.9); % tV = mapminmax('reverse',t,TS);
    t = single(t);
    clear r tA thesis train var fileset % x1 t1
    % disp('Input vector') ,disp(x1)
    % disp('Target vector'), disp(t1)
%  ----------------------------------------------------------
if (nargin  < 2)
    disp('weights v and w are getting initialised randomly');
        v =  randn(n,p);
        w  = randn(p,m);
        v0 = randn(trainRecords,p);
        w0 = randn(trainRecords,m);
end
%%%First hidden Layer
    zin = zeros(trainRecords,p);
    z =  zeros(trainRecords,p);
    din = zeros(trainRecords,p);
    dj =  zeros(trainRecords,p);
    chv = zeros(n,p);
    chv0 = zeros(1,p);
%%%Output Layer
    yin = zeros(trainRecords,m);
    y = zeros(trainRecords,m);
    d = zeros(trainRecords,m);
    chw = zeros(p,m);
    chw0 = zeros(1,m);
iteration =1;
er = 0; error = 0; forceQuit = false;

%%  ==Step_1==While_stoping_condition_is_false==do_step_2-9===
while er==0 % do Step 2-9
    errorMax(iteration) = max(max(error));
    disp(sprintf('Epoch : %4g, max err : %d',iteration, errorMax(iteration)));
    %     totalerr = 0;
%%% ==Step_2==For_Each_Training_pair===========do_Steps_3-8===
%% Feed forward:
%%% ==Step_3==X_get_Input=====================================
%%% ==Step_4==================================================
%%% First Layer
    zin = zeros(trainRecords,p);
    zin =  (x * v) + v0;
    z = ((2./(1+exp(-zin)))-1); %activation function 
%%% ==Step_5==================================================
%%% Second Layer
    yin = zeros(trainRecords,m);
    yin = z * w + w0;
    y = ((2./(1+exp(-yin)))-1); %activation function 
    %        totalerr = 0.5 * ((t(T,j) - y(T,j))^2)+totalerr;
%% Backpropagation of error (Training Started)
%%% ==Step_6==================================================
    d = zeros(trainRecords,m);
    %%% Error Info = (t - y) * (Derivative of Second layer activation function)
    d = (t - y).*((1/2).*(1+y).*(1 - y));  
%%% ==Step_7==================================================
    for T=1:trainRecords
        for j =1:p        
%             if(j == 1)
%                 chw(j,:) = alpha * d(T,:) * z(T,j);
%                 din(T,j) = sum(d(T,:) .* w(j,:));
% %%%     Error Info = din * (Derivative of First layer activation function)
%                 dj(T,j) = (din(T,j) * ((1/2) * (1 + z(T,j))* (1 - z(T,j))));
%     %                dj = tansig('dn',z);
%                 chv(:,j) = alpha * dj(T,j) * x(T,:);
%                 continue
%             end
            chw(j,:) = alpha * d(T,:) * z(T,j); %+ alp * (chw(j,:)- chw(j-1,:));
            din(T,j) = sum(d(T,:) .* w(j,:));
%%%     Error Info = din * (Derivative of First layer activation function)
            dj(T,j) = (din(T,j) * ((1/2) * (1 + z(T,j))* (1 - z(T,j))));
            chv(:,j) = alpha * dj(T,j) * x(T,:)'; % + (alp * (chv(:,j) -chv(:,j-1)));
    %               chv(j,:) = alpha * dj(T,:) * x(T,j);
            chw0 = alpha * d(T,:);
            chv0 = alpha * dj(T,j);
        end
%% ==Step_8==Update_weights_and_biases========================
        w  = w  + chw;
        w0(T,:) = w0(T,:) + chw0;
        v  = v  + chv;
        v0(T,:) = v0(T,:) + chv0;        
    end
%%  ==Step_9==Test_stoping_condition==========================
    error = sqrt((t-y).^2);
%%% Step 9 Update the stopping condition variable
    if max(max(error)) < 0.0831 % W/P = e, W =weights,P =inputs, e = errors
        er =1;
    else
        er = 0;
    end
    iteration = iteration +1;
    %finerr = totalerr/(trainRecords*n);
    %disp(finerr)
    %if finerr < 0.01    er = 1; else    er = 0; end
    %disp(sprintf('the error : %d, finerr : %d',error , finerr));
    if (iteration > 3000)
        forceQuit = true;
        break
    end
end %% End of while loop Step 1
if(~forceQuit)
    save('weight6040.dat','v','v0','w','w0') %, 'x','tA');
    erLine = ones(1,size(errorMax,2))*0.05;
    clf('reset'), cla reset, 
    plot(1:size(errorMax,2),errorMax,1:size(errorMax,2),erLine,'r')
    xlabel('iteration '), ylabel('error '), title('Plot of the error')
else
    msgbox('Maximum number of Epoch reached with out convergence','No convergence')
end
end %% End of Function / File