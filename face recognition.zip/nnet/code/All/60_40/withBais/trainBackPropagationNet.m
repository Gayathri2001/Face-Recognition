function [v,v0,w,w0] = trainBackPropagationNet(v,v0,w,w0)
%% Opening of the Input / Target Files
%tic, t = toc
cd(getenv('thesis'))
paths
disp('Loading the input vector x and target vectors')
cd(strcat(getenv('thesis'),'\res\database\Face Database\ExtraFeatures\points_20'));
FaceDataset = FaceDatabase;
train = D6040(FaceDataset);
trainRecords = sum(train(:));
x = zeros(trainRecords,40); x = single(x);
t1 = false(trainRecords,5);
fileset = filesetter(FaceDataset, train);
for var=1:trainRecords  
    [x1(var,:),t1(var,:)] = getFileData(fileset(var,:)); %row wise
end
r = randperm(trainRecords);
for i=1:trainRecords
    x(i,:) = x1(r(i),:);
    tA(i,:) = t1(r(i),:);
end
[t,TS] = mapminmax(double(tA),-.9,.9);
% disp('Input vector') ,disp(x1)
% disp('Target vector'), disp(t1)

%% Enter the Architecture detail
disp('Enter the Architecture detail');
n = 40;  %INPUT      
p = 46; %n/4;  HIDDEN     Because W/p = e and 60% is 46, 100% is 76
m = 5; % OUTPUT
alpha = input('Enter the Learning rate :  ');
alp = input('Enter the Momentum rate :  ');
%mov = struct('cdata',{},'colormap',{});

%% Preprocess the data
%[in,out,pf, tf] = imgHistGrayResizeMap(filename);

%% step 0 Initialization
if (nargin  < 2)
    disp('weights v and w are getting initialised randomly');
        v = -0.5+(0.5-(-0.5))*single(rand(n,p)); % int8(ones(n,p));  
        w  = -0.5+(0.5-(-0.5))*single(rand(p,m)); %int8(zeros(p,m)); 

        v0 = -0.5+(0.5-(-0.5))*rand(trainRecords,p);
        w0 = -0.5+(0.5-(-0.5))*rand(trainRecords,m);
end
chw = zeros(p,m);
chw0 = zeros(trainRecords,m);
chv = zeros(n,p);
chv0 = zeros(trainRecords,p);
dk = zeros(trainRecords,m);
yin = zeros(trainRecords,m);
y = zeros(trainRecords,m);
zin = zeros(trainRecords,p);
dinj = zeros(trainRecords,p);
dj =  zeros(trainRecords,p);
z =  zeros(trainRecords,p);
iteration =1;
er = 0; error = 0; %errorRep = 0;

%% step 1 While stoping condition is false do step 2 -9
while er==0 % do Step 2-9
   disp(sprintf('Epoch %d and max err : %d'  ...
               ,iteration, max(max(error))));
errorMax(iteration) = max(max(error));
%     totalerr = 0;
% Step 2 For each Training pair, od Steps 3-8
%         tV = mapminmax('reverse',x,TS);

    zin =  x * v + v0;
    z = ((2./(1+exp(-zin)))-1); %activation function 
%        z = tansig(zin);

    yin = z * w + w0;
%        y = tansig(yin);
    y = ((2./(1+exp(-yin)))-1); %activation function 
%        totalerr = 0.5 * ((t(T,j) - y(T,j))^2)+totalerr;

    dk = (t - y).*((1/2).*(1+y).*(1 - y)); %Derivative of activation function 
%        dk = tansig('dn',y);
    for T=1:trainRecords
        for j =1:p
            if(j == 1)
                chw(j,:) = alpha * dk(T,:) * z(T,j);
                dinj(T,j) = sum(dk(T,:) .* w(j,:));
                dj(T,j) = (dinj(T,j) * ((1/2) * (1 + z(T,j))* (1 - z(T,j))));
    %                dj = tansig('dn',z);
                chv(:,j) = alpha * dj(T,j) * x(T,:);
                continue
            end
            chw(j,:) = alpha * dk(T,:) * z(T,j) + alp * (chw(j,:)- chw(j-1,:));
            dinj(T,j) = sum(dk(T,:) .* w(j,:));
            dj(T,j) = (dinj(T,j) * ((1/2) * (1 + z(T,j))* (1 - z(T,j)))); %Derivative of activation function 
%                dj = tansig('dn',z);
            chv(:,j) = alpha * dj(T,j) * x(T,:) + (alp * (chv(:,j) -chv(:,j-1)))';
%               chv(j,:) = alpha * dj(T,:) * x(T,j);
        end
    end
    chw0 = alpha * dk;
    chv0 = alpha * dj;           
    v  = v  + chv;
    v0 = v0 + chv0;
    w  = w  + chw;
    w0 = w0 + chw0;
%    h1 = subplot(2,1,1);   surf(h1,im2double(v)); 
%    h2 = subplot(2,1,2);   surf(h2,im2double(w));
%     getframe;%     F(iteration) = getframe; movie(F);
%disp('value of y at this iteration');
%disp(y)
error = sqrt((t-y).^2);
% interRep = dk.^2;
% errorRep = 1/2 * sum(interRep(:));
if max(max(error)) < 0.0831 % W/P = e, W =weights,P =inputs, e = errors
    er =1;
else
    er = 0;
end
iteration = iteration +1;
% alpha = alpha * .999;
%finerr = totalerr/(trainRecords*n);
%disp(finerr)
%if finerr < 0.01    er = 1; else    er = 0; end
%disp(sprintf('the error : %d, finerr : %d',error , finerr));
% img = error *255;
% img = padarray(img, [0  14]);
% mov(iteration).cdata = double(img);
% mov(iteration).colormap = [];
%codecs = videoWriter([],'codecs')
% if (iteration >=1500)
%     return;
% end
end %% End of wile loop Step 1
% movie2avi(mov, 'MatMov.avi', 'compression', 'Indeo5');
save('weight6040.dat','v','v0','w','w0') %, 'x','tA');
clf('reset'), cla reset, plot(errorMax)
xlabel('iteration '), ylabel('error '), title('Plot of the error')
end %% End of Function / File