function [v,v0,w,w0] = trainBackPropagationNet(v,v0,w,w0)
%%  ==Step_0==Initialization=================================
%%% Enter the Architecture detail
    disp('Enter the Architecture detail');
    n = 40;  %INPUT      
    p = 2; %  HIDDEN     Because W/p = e and 60% is 46, 100% is 76
    m = 5; % OUTPUT
    alpha = input('Enter the Learning rate :  ');
    alp = input('Enter the Momentum rate :  ');
    %mov = struct('cdata',{},'colormap',{});
%  -----------------------------------------------------------
%%% Opening of the Input / Target Files
%tic, t = toc
    cd(getenv('thesis'))
    paths
    disp('Loading the input vector x and target vectors')
    cd(strcat(getenv('thesis'),'\res\database\Face Database\ExtraFeatures\points_20'));
    FaceDataset = FaceDatabase;
    train = D6040(FaceDataset);
    trainRecords = sum(train(:));
    x = zeros(trainRecords,n); x = single(x);
    t1 = false(trainRecords,m);
    fileset = filesetter(FaceDataset, train);
    for var=1:trainRecords  
        [x1(var,:),t1(var,:)] = getFileData(fileset(var,:)); %row wise
    end
    r = randperm(trainRecords);
    for i=1:trainRecords
        x(i,:) = x1(r(i),:);
        tA(i,:) = t1(r(i),:);
    end
    [t,TS] = mapminmax(double(tA),-.9,.9); % tV = mapminmax('reverse',t,TS);
    t = single(t);
    clear r tA thesis train var fileset % x1 t1
    % disp('Input vector') ,disp(x1)
    % disp('Target vector'), disp(t1)
%  ----------------------------------------------------------
if (nargin  < 2)
    disp('weights v and w are getting initialised randomly');
        v = -0.5+(0.5-(-0.5))*single(rand(n,p)); % int8(ones(n,p));  
        w  = -0.5+(0.5-(-0.5))*single(rand(p,m)); %int8(zeros(p,m)); 

        v0 = -0.5+(0.5-(-0.5))*rand(trainRecords,p);
        w0 = -0.5+(0.5-(-0.5))*rand(trainRecords,m);
end
%%%First hidden Layer
    chv = zeros(n,p);
    chv0 = zeros(trainRecords,p);
    zin = zeros(trainRecords,p);
    dinj = zeros(trainRecords,p);
    dj =  zeros(trainRecords,p);
    z =  zeros(trainRecords,p);
%%%Second hidden Layer
    chw = zeros(p,m);
    chw0 = zeros(trainRecords,m);
    dk = zeros(trainRecords,m);
    yin = zeros(trainRecords,m);
    y = zeros(trainRecords,m);
iteration =1;
er = 0; error = 0; %errorRep = 0;

%%  ==Step_1==While_stoping_condition_is_false==do_step_2-9===
while er==0 
    errorMax(iteration) = max(max(error));
    disp(sprintf('Epoch : %4g, max err : %d',iteration, errorMax(iteration)));
    %     totalerr = 0;
%%% ==Step_2==For_Each_Training_pair===========do_Steps_3-8===
%% Feed forward:
%%% ==Step_3==X_get_Input=====================================
%%% ==Step_4==================================================
%%% First Layer
    zin =  x * v + v0;
%     for i=1:trainRecords
%         zin(i,:) = zin(i,:) + v0;
%     end
    z = ((2./(1+exp(-zin)))-1); %activation function 
    %        z = tansig(zin);
%%% ==Step_5==================================================
%%% Second Layer
    yin = z * w + w0;
%     for i=1:trainRecords
%         yin(i,:) = yin(i,:) + w0;
%     end
    %        y = tansig(yin);
    y = ((2./(1+exp(-yin)))-1); %activation function 
    %        totalerr = 0.5 * ((t(T,j) - y(T,j))^2)+totalerr;
%% Backpropagation of error (Training Started)
%%% ==Step_6==================================================
    %%% Error Info = (t - y) * (Derivative of Second layer activation function)
    dk = (t - y).*((1/2).*(1+yin).*(1 - yin));  
    %        dk = tansig('dn',y);
%%% ==Step_7==================================================
    for T=1:trainRecords
        for j =1:p        
            if(j == 1)
                chw(j,:) = alpha * dk(T,:) * z(T,j);
                dinj(T,j) = sum(dk(T,:) .* w(j,:));
%%%     Error Info = dinj * (Derivative of First layer activation function)
                dj(T,j) = (dinj(T,j) * ((1/2) * (1 + zin(T,j))* (1 - zin(T,j))));
    %                dj = tansig('dn',z);
                chv(:,j) = alpha * dj(T,j) * x(T,:);
                continue
            end
            chw(j,:) = alpha * dk(T,:) * z(T,j) + alp * (chw(j,:)- chw(j-1,:));
            dinj(T,j) = sum(dk(T,:) .* w(j,:));
%%%     Error Info = dinj * (Derivative of First layer activation function)
            dj(T,j) = (dinj(T,j) * ((1/2) * (1 + zin(T,j))* (1 - zin(T,j))));
    %                dj = tansig('dn',z);
            chv(:,j) = alpha * dj(T,j) * x(T,:) + (alp * (chv(:,j) -chv(:,j-1)))';
    %               chv(j,:) = alpha * dj(T,:) * x(T,j);
        end
    end
%% ==Step_8==Update_weights_and_biases========================
        chw0 = alpha * dk;%(T,:);
        chv0 = alpha * dj;%(T,:);
        w  = w  + chw;
        w0 = w0 + chw0;
        v  = v  + chv;
        v0 = v0 + chv0;
    %    h1 = subplot(2,1,1);   surf(h1,im2double(v)); 
    %    h2 = subplot(2,1,2);   surf(h2,im2double(w));
    %     getframe;%     F(iteration) = getframe; movie(F);
    %disp('value of y at this iteration');
    %disp(y)
%%  ==Step_9==Test_stoping_condition==========================
    error = sqrt((t-y).^2);
%%% Update the stopping condition variable
    if max(max(error)) < 0.0831 % W/P = e, W =weights,P =inputs, e = errors
        er =1;
    else
        er = 0;
    end
    iteration = iteration +1;
    % alpha = alpha * .999;
    %finerr = totalerr/(trainRecords*n);
    %disp(finerr)
    %if finerr < 0.01    er = 1; else    er = 0; end
    %disp(sprintf('the error : %d, finerr : %d',error , finerr));
    % img = error *255;
    % img = padarray(img, [0  14]);
    % mov(iteration).cdata = double(img);
    % mov(iteration).colormap = [];
    %codecs = videoWriter([],'codecs')
    % if (iteration >=1500)
    %     return;
    % end
end %% End of while loop Step 1
% movie2avi(mov, 'MatMov.avi', 'compression', 'Indeo5');
save('weight6040.dat','v','v0','w','w0') %, 'x','tA');
clf('reset'), cla reset, plot(errorMax)
xlabel('iteration '), ylabel('error '), title('Plot of the error')
end %% End of Function / File