function testBackPropagationNet()
cd(getenv('thesis'))
paths
cd(strcat(getenv('thesis'),'\res\database\Face Database\ExtraFeatures\points_20'));

%% step 0 Initialization
FaceDataset = FaceDatabase;
[train , test] = D6040(FaceDataset);
clear train
% trainRecords = sum(train(:));
testRecords = sum(test(:));

n = 40; % INPUT
p = 2; % HIDDEN
m = 5; % OUTPUT
yin = zeros(testRecords,m); 
y = zeros(testRecords,m);
zin = zeros(testRecords,p);
z =  zeros(testRecords,p);
load('weight6040.dat','-mat','v','v0','w','w0') %, 'x','t1');
% v0(603:919,:) = 0; w0(603:919,:) = 0; 
x = zeros(testRecords,40); x = single(x);
t1 = false(testRecords,5);
fileset = filesetter(FaceDataset, test);
for var=1:testRecords  
    [x(var,:),t1(var,:)] = getFileData(fileset(var,:)); 
end
% r = randperm(testRecords);
% for i=1:testRecords
%     x(i,:) = x1(r(i),:); %     tA(i,:) = t1(r(i),:);
% end
x(603:919,:) = x(1:317,:);  t1(603:919,:) = t1(1:317,:);
%     v0(603:919,:) = [];          w0(603:919,:) = [];
%% step 1 For each input vector, do step 2 -3
    %Step 2 Compute the product of inputs and input weights plus bais
    zin =  x * v + v0;
    z = ((2./(1+exp(-zin)))-1);     %activation function 
%        z = tansig(zin);
    %Step 3 Compute the product of hidden units and first layer weights plus bais
    yin = z * w + w0;
%        y = tansig(yin);
    y = ((2./(1+exp(-yin)))-1);     %activation function 
%        totalerr = 0.5 * ((t(T,j) - y(T,j))^2)+totalerr;
%% Step 4 Verify the results    

    thresh = im2bw(y,graythresh(y));
%     thresh(603:919,:) = [];
    matchFound = 0; 
%     matchUnFound = 0;
    for i=1:testRecords
        if(isequal(t1(i,:),thresh(i,:)))
            matches(i) = true;
            matchFound = matchFound + 1;
%         else
%             matches(i) = false;
%             matchUnFound = matchUnFound + 1;
        end
    end
%     if (isequal(t1,thresh))
        eff = round(matchFound /testRecords *100);
        msgbox(sprintf('%3d %% efficency',eff),'Efficency');
%     end    
% any
% clc
% for j=1:919
%     str = '';
%     for i=1:5
%         str = strcat(str, sprintf('%d',thresh(j,i)));
%     end
%     thresh2(j) = bin2dec(str);
%     disp(sprintf('%3d,%2d',j,thresh2(j)))
% end
end %% End of Function / File