function testingBackPropagationNetAll()
cd(getenv('thesis'))
paths
cd(strcat(getenv('thesis'),'\res\database\Face Database\ExtraFeatures\points_20'));

%% step 0 Initialization
TotalRecord = 1520;
n = 40; % INPUT
p = 2; % HIDDEN
m = 5; % OUTPUT
yin = zeros(TotalRecord,m);
y = zeros(TotalRecord,m);
zin = zeros(TotalRecord,p);
z =  zeros(TotalRecord,p);
load('weightAll.dat','-mat','v','v0','w','w0');
x1 = zeros(TotalRecord,40); x1 = single(x1);
t1 = false(TotalRecord,5);
for var=1:TotalRecord  %1520
    [x1(var,:),t1(var,:)] = getFileData(sprintf('bioid_%04d.pts', var)); %row wise
end
noise = rand(1,TotalRecord) * round(sum(x1(:))/size(x1(:),1));
for var=1:TotalRecord
    x1(var,:) = x1(var,:) + noise(var);
end
%[t,TS] = mapminmax(double(t1),-.9,.9);

%% step 1 For each input vector, do step 2 -3
    %Step 2 Compute the product of inputs and input weights plus bais
    zin =  x1 * v + v0;
    z = ((2./(1+exp(-zin)))-1);     %activation function 
%        z = tansig(zin);
    %Step 3 Compute the product of hidden units and first layer weights plus bais
    yin = z * w + w0;
%        y = tansig(yin);
    y = ((2./(1+exp(-yin)))-1);     %activation function 
%        totalerr = 0.5 * ((t(T,j) - y(T,j))^2)+totalerr;
%% Step 4 Verify the results    
    thresh = im2bw(y,graythresh(y));
    matchFound = 0; 
    if (isequal(t1,thresh))
        msgbox('100 % efficency','Efficency');
    else
        for i=1:TotalRecord
            if(isequal(t1(i,:),thresh(i,:)))
                matches(i) = true;
                matchFound = matchFound + 1;
            end
        end
    end
        eff = floor(matchFound / TotalRecord *100);
        msgbox(sprintf('%3d %% efficency',eff),'Efficency');
% any
% for j=1:1520
%     str = '';
%     for i=1:5
%         str = strcat(str, sprintf('%d',t1(j,i)));
%     end
%     disp(bin2dec(str))
%     numb2(j) = bin2dec(str);
% end
end %% End of Function / File