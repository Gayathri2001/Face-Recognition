function [v,v0,w,w0] = trainBackPropagationNetAll(v,v0,w,w0)
%%  ==Step_0==Initialization=================================
%%% Enter the Architecture detail
    disp('Enter the Architecture detail');
    n = 40; % INPUT
    p = 2; % HIDDEN
    m = 5; % OUTPUT
    TotalRecord = 1520; %No of Records
    alpha = input('Enter the Learning rate :  ');
    alp = input('Enter the Momentum rate :  ');
    %mov = struct('cdata',{},'colormap',{});
%  -----------------------------------------------------------
%%% Opening of the Input / Target Files
    cd(getenv('thesis'))
    paths
    disp('Loading the input vector x and target vectors')
    cd(strcat(getenv('thesis'),'\res\database\Face Database\ExtraFeatures\points_20'));
    x = zeros(TotalRecord,n); x = single(x);
    t1 = false(TotalRecord,m);
    for var=1:TotalRecord  %1520
        [x1(var,:),t1(var,:)] = getFileData(sprintf('bioid_%04d.pts', var)); %row wise
    end
    r = randperm(1520);
    for i=1:1520
        x(i,:) = x1(r(i),:);
        tA(i,:) = t1(r(i),:);
    end
    [t,TS] = mapminmax(double(tA),-.9,.9); %   tV = mapminmax('reverse',t,TS);
    t = single(t);
    clear r tA thesis train var % x1 t1
    % disp('Input vector') ,disp(x1)
    % disp('Target vector'), disp(t1)
%  ----------------------------------------------------------
if (nargin  < 2)
    disp('weights v and w are getting initialised randomly');
        v = -0.5+(0.5-(-0.5))*single(rand(n,p)); % int8(ones(n,p));  
        w  = -0.5+(0.5-(-0.5))*single(rand(p,m)); %int8(zeros(p,m)); 

        v0 = -0.5+(0.5-(-0.5))*rand(TotalRecord,p);
        w0 = -0.5+(0.5-(-0.5))*rand(TotalRecord,m);
end
%%%First hidden Layer
    chv = zeros(n,p);
    chv0 = zeros(TotalRecord,p);
    zin = zeros(TotalRecord,p);
    dinj = zeros(TotalRecord,p);
    dj =  zeros(TotalRecord,p);
    z =  zeros(TotalRecord,p);
%%%Second hidden Layer
    chw = zeros(p,m);
    chw0 = zeros(TotalRecord,m);
    y = zeros(TotalRecord,m);
    dk = zeros(TotalRecord,m);
    yin = zeros(TotalRecord,m);
iteration =1;
er = 0; error = 0; errorRep = 0;

%%  ==Step_1==While_stoping_condition_is_false==do_step_2-9===
while er==0 
    errorMax(iteration) = max(max(error));
    disp(sprintf('Epoch: %4d, max err: %d ',iteration, errorMax(iteration)));
%     totalerr = 0;
%%% ==Step_2==For_Each_Training_pair===========do_Steps_3-8===
%% Feed forward:
%%% ==Step_3==X_get_Input=====================================
%%% ==Step_4==================================================
%%% First Layer
    zin =  x * v + v0;
    z = ((2./(1+exp(-zin)))-1); %activation function 
%        z = tansig(zin);
%%% ==Step_5==================================================
%%% Second Layer
    yin = z * w + w0;
%        y = tansig(yin);
    y = ((2./(1+exp(-yin)))-1); %activation function 
%        totalerr = 0.5 * ((t(T,j) - y(T,j))^2)+totalerr;
%% Backpropagation Training Started
%%% ==Step_6==================================================
    %%% Error Info = (t - y) * (Derivative of Second layer activation function)
    dk = (t - y).*((1/2).*(1+y).*(1 - y));
%        dk = tansig('dn',y);
%%% ==Step_7==================================================
    for T=1:TotalRecord
        for j =1:p
            if(j == 1)
                chw(j,:) = alpha * dk(T,:) * z(T,j);
                dinj(T,j) = sum(dk(T,:) .* w(j,:));
%%%     Error Info = dinj * (Derivative of First layer activation function)
                dj(T,j) = (dinj(T,j) * ((1/2) * (1 + z(T,j))* (1 - z(T,j))));
    %                dj = tansig('dn',z);
                chv(:,j) = alpha * dj(T,j) * x(T,:);
                continue
            end
            chw(j,:) = alpha * dk(T,:) * z(T,j) + alp * (chw(j,:)- chw(j-1,:));
            dinj(T,j) = sum(dk(T,:) .* w(j,:));
%%%     Error Info = dinj * (Derivative of First layer activation function)
            dj(T,j) = (dinj(T,j) * ((1/2) * (1 + z(T,j))* (1 - z(T,j))));
    %                dj = tansig('dn',z);
            chv(:,j) = alpha * dj(T,j) * x(T,:) + (alp * (chv(:,j) -chv(:,j-1)))';
    %               chv(j,:) = alpha * dj(T,:) * x(T,j);
        end
%         w  = w  + chw;
%         v  = v  + chv;
    end
%% ==Step_8==Update_weights_and_biases========================
    chw0 = alpha * dk;
    chv0 = alpha * dj;           
     v  = v  + chv;
    v0 = v0 + chv0;
     w  = w  + chw;
    w0 = w0 + chw0;
    %    h1 = subplot(2,1,1);   surf(h1,im2double(v)); 
    %    h2 = subplot(2,1,2);   surf(h2,im2double(w));
    %     getframe;%     F(iteration) = getframe; movie(F);
    %disp('value of y at this iteration');
    %disp(y)
%%  ==Step_9==Test_stoping_condition==========================
    error = sqrt((t-y).^2);
    %%% Update the stopping condition variable
    if max(max(error)) < 0.05      % W/P = e, W =weights,P =inputs, e = errors
        er =1;
    else
        er = 0;
    end
    iteration = iteration +1;
    % alpha = alpha * .999;
    %finerr = totalerr/(TotalRecord*n);
    %disp(finerr)
    %if finerr < 0.01    er = 1; else    er = 0; end
    %disp(sprintf('the error : %d, finerr : %d',error , finerr));
    % img = error *255;
    % img = padarray(img, [0  14]);
    % mov(iteration).cdata = double(img);
    % mov(iteration).colormap = [];
    %codecs = videoWriter([],'codecs')
    % if (iteration >=1500)
    %     return;
    % end
end %% End of while loop Step 1
% movie2avi(mov, 'MatMov.avi', 'compression', 'Indeo5');
save('weightAll.dat','v','v0','w','w0');
clf('reset'), cla reset, plot(errorMax)
xlabel('iteration '), ylabel('error '), title('Plot of the error')
end %% End of Function / File