function net = trBPM(MainGUIdata)
%% Train Back propagation net using MAtlab created network
% zscore, trainlm 2. trainrp 3. trainscgb traingda
%Nw = (I+1)*H+(H+1)*O % Neq = N*O
%Nw = (40+1)*41+(41+1)*5 = 1891  %Neq = 1520*5 = 7600   %r = Neq/Nw = 4.02
%Nw = (40+1)*41+(41+1)*23 = 2647 %Neq = 1520*23 = 34960 %r = Neq/Nw = 13.2
% For no of hidden nodes, I generally use a binary search based on the ratios
% r = Neq/Nw = [1, 2, 4, 8, 16, 32]
%%  ==Step_0==Initialization=================================
clc
%%% Opening of the Input / Target Files
%tic, t = toc
    disp('Loading the input vector p and target vectors')
    cd(fileparts(mfilename('fullpath')))
    directory = pwd;
    cd('../../../')
    paths
    cd('.\nnet\code\recordKeeping')
    global p t inputByPerson targetByPerson
%     charData 
    if nargin < 1
        disp(sprintf('select the number of records \n'))
        selection = input('Records [1]=30+, 2=Simulated Records, 3 = replicated Records :');
        if isempty(selection),        selection = 1;    end
        epa = input('Enter the maximum number of Epochs: 200 | [100=oneHour] ');
        if isempty(epa),      epa = 100;    end
        alpha = input('Enter the Learning rate            : 0.05 | 0.01 | [0.005] ');
        if isempty(alpha),    alpha =  0.005;    end
    else
        selection = MainGUIdata.selection;
        epa = MainGUIdata.epochs;
        alpha = MainGUIdata.alpha;
    end
    if(selection == 1)
        recs = input('Enter the number of records per person : [35] ');
        if isempty(recs),      recs = 35;    end
        if(~((exist(sprintf('trainRec%d.mat',recs),'file') == 2) && (exist(sprintf('testRec%d.mat',recs),'file') == 2)))
            save6040(recs);
        end
        load(sprintf('trainRec%d.mat',recs))
    elseif(selection == 2)
        if(~(exist('trainSimulatedRecord.mat','file') == 2))
            getSimulatedRecordsByPersons();
        end
        load trainSimulatedRecord
    else
        if(~(exist('trainReplicatedRecords.mat','file') == 2))
            replicatedRecords(); 
        end
        load trainReplicatedRecords
    end
    
    disp('Loading of input vector p and target vectors done')
%%% Randomization of Dataset
    trainRecords = size(p,1); 
    r = randperm(trainRecords);
    p1 = p; t1 = t;
    for i=1:trainRecords
        p(i,:) = p1(r(i),:);
        t(i,:) = t1(r(i),:); %tA
    end
%     p(:,1:2) = [];
    clear p1 t1 trainRecords

%  ----------------------------------------------------------
    cd(directory);
    if(selection == 1)
        if(~(exist('net30+.mat','file') == 2))
        %%% Enter the Architecture detail
        %     e = 0.0415880; % error limit 0.0406189 0.0406042
        % MSE 0.00684314
            disp(sprintf('Number of persons are %d with %d records', persons,recs));
            n = size(p,2);  %INPUT
            disp('Enter the Architecture detail');
            h = input('Enter the number of Hidden neurons : [16] ');
            if isempty(h),        h = 16;    end   %  HIDDEN   Because W/p = e 
            m = size(t,2); % OUTPUT
        %     alp = input('Enter the Momentum rate :  ');
            net  = newff(minmax(p'),[h m],{'tansig','purelin'},'trainoss');
        else
            load net30+
        end
    elseif selection == 2
        if(~(exist('netSimulatedRecord.mat','file') == 2))
            disp('Enter the Architecture detail');
            disp(sprintf('Number of persons are %d with %d records', 23,150));
            n = size(p,2);  %INPUT
            h = input('Enter the number of Hidden neurons : [16] ');
            if isempty(h),        h = 16;    end   %  HIDDEN   Because W/p = e 
            m = size(t,2); % OUTPUT
        %     alp = input('Enter the Momentum rate :  ');
            net  = newff(minmax(p'),[h m],{'tansig','purelin'},'trainoss');
        else
            load netSimulatedRecord
        end
    else
        if(~(exist('netReplicatedRecords.mat','file') == 2))
            disp('Enter the Architecture detail');
            disp(sprintf('Number of persons are %d with %d records', 23,150));
            n = size(p,2);  %INPUT
            h = input('Enter the number of Hidden neurons : [16] ');
            if isempty(h),        h = 16;    end   %  HIDDEN   Because W/p = e 
            m = size(t,2); % OUTPUT
        %     alp = input('Enter the Momentum rate :  ');
            net  = newff(minmax(p'),[h m],{'tansig','purelin'},'trainlm'); %trainoss
            net.trainParam.mem_reduc = 2;
        else
            load netReplicatedRecords
        end
    end
    net.trainParam.epochs=epa;
    net.trainParam.goal=1e-5; % 0.0405
    if nargin < 1    
        net.trainParam.show=10;
        choice = input('select the training algorithm: trainoss | trainrp | [trainlm] ');
        if isempty(choice),        choice = 'trainlm';    end
        net.trainFcn = choice;
    else
        net.trainParam.show = MainGUIdata.show;
        net.trainFcn = MainGUIdata.trainingFn;
    end
    net.trainParam.time=round(60*60*2.2); % one hour
    net.trainParam.lr=alpha; % 0.05
    % net.trainParam.lr_inc = 1.05;
    % net.trainParam.mc =0.9; %0.9
    p = transpose(p);t = transpose(t);
    [net,tr] = train(net,p,t);
    c = input('save the net: [y] ','s');
    if isempty(c),        c = 'y';    end
    if(c == 'y')
        if(selection == 1)
            save('net30+','net')
        elseif selection == 2
            save('netSimulatedRecord','net')
        else
            save('netReplicatedRecords','net')
        end
    end
end %% End of Function / File