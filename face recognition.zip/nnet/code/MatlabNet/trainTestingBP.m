clc
load('../recordKeeping/trainRec.mat')
cd('..\preprocessing')
p =RTSInvariant(p);
load net6040
%MSE 0.0298265/0.0001  MSE 0.00861097
p = transpose(p);t = transpose(t); 
net.trainFcn = 'trainlm';
net.trainParam.epochs=4000;
net.trainParam.goal=0.001;
net.trainParam.show=10;
[net,tr] = train(net,p,t);
