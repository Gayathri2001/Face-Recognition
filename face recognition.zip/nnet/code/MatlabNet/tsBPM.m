function s = tsBPM(MainGUIdata)
    clc
    cd(fileparts(mfilename('fullpath')))
    directory = pwd; 
    cd ../../../;
    thesis = pwd;
    path(strcat(thesis, '\nnet\code\recordKeeping;'), path);
    path(strcat(thesis, '\nnet\code\preprocessing;'), path);
    path(strcat(thesis, '\nnet\code\MatlabNet;'), path);
    if nargin < 1
        selection = input('Records [1]=30+, 2=50, 3=replicated Records, 4= Simulated Records :');
        if isempty(selection),        selection = 1;    end
        disp(sprintf('\nValidation or Testing'))
        trainTest = input('1 = Validation, [2] testing:');
        if isempty(trainTest),        trainTest = 2;    end
        if(selection == 1 && trainTest == 1)
            load net30+
            load trainRec35.mat
        elseif (selection == 2 && trainTest == 1)
            load net50
            load trainRec50.mat
        elseif (selection == 3 && trainTest == 1)
            load netReplicatedRecords
            load trainReplicatedRecords.mat
            persons = 23;
        elseif (selection == 4 && trainTest == 1)
            load netSimulatedRecord
            load trainSimulatedRecord.mat
            persons = 23;
        elseif(selection == 1 && trainTest == 2)
            load net30+
            load testRec35.mat
        elseif (selection == 2 && trainTest == 2)
            load net50
            load testRec50.mat
        elseif (selection == 3 && trainTest == 2)
            load netReplicatedRecords
            load testReplicatedRecords.mat
            persons = 23;
        elseif(selection == 4 && trainTest == 2)
            load netSimulatedRecord
            load testSimulatedRecord.mat
            persons = 23;
        end
    else
        selection = MainGUIdata.selection;
        trainTest = MainGUIdata.ValidTest;
        if(selection == 1 && trainTest == 1)
            eval(['load ' MainGUIdata.netName]);
            eval(['load train' MainGUIdata.database])
        elseif (selection == 2 && trainTest == 1)
            eval(['load ' MainGUIdata.netName]);
            eval(['load train' MainGUIdata.database])
            persons = 23;
        elseif (selection == 3 && trainTest == 1)
            eval(['load ' MainGUIdata.netName]);
            eval(['load train' MainGUIdata.database])
            persons = 23;
        elseif (selection == 4 && trainTest == 1)
            eval(['load ' MainGUIdata.netName]);
            eval(['load train' MainGUIdata.database])
            persons = 23;
        elseif(selection == 1 && trainTest == 2)
            eval(['load ' MainGUIdata.netName]);
            eval(['load test' MainGUIdata.database])
        elseif (selection == 2 && trainTest == 2)
            eval(['load ' MainGUIdata.netName]);
            eval(['load test' MainGUIdata.database])
            persons = 23;
        elseif (selection == 3 && trainTest == 2)
            eval(['load ' MainGUIdata.netName]);
            eval(['load test' MainGUIdata.database])
            persons = 23;
        elseif(selection == 4 && trainTest == 2)
            eval(['load ' MainGUIdata.netName]);
            eval(['load test' MainGUIdata.database])
        end
    end
    cd(directory);
    p = p'; t = t';
    a = sim(net,p)'; 
    a = mapminmax(a);
    % a = a + (1 - max(a(:)));
    matchFound = 0; 
     for i=1:size(p,2)
    %     a(i,:) = sim(net,p(:,i));
        b(i,:) = im2bw(a(i,:),max(a(i,:))-0.00001);
        if(isequal(double(b(i,:)),t(:,i)'))
            res(i) = true;
            matchFound = matchFound + 1;
        end
     end
     numb = zeros(1,size(p,2));  numb2 = zeros(1,size(p,2));
    t = t';
     for i=1:size(b,1)
        val = 0;
        for j=size(b,2):-1:1
            val = val +1;
            if(b(i,j) == 1)
                numb(i) = val;
            end
            if(t(i,j) == 1)
                numb2(i) = val;
            end
        end
    end
    s = struct('a',a,'b',b,'res',res,'p',p,'t',t,'numb',numb,'numb2',numb2, ...
                'matchFound',matchFound,'totalRecords',size(b,1));
    plot(s.numb,'b'); hold on; plot(s.numb2,'r')
    if selection == 1
        set(gca,'ytick',persons); set(gca,'xtick',0:30:size(b,1))
        figure,plot(s.numb,'b'); set(gca,'ytick',persons); set(gca,'xtick',0:30:size(b,1))
        figure,plot(s.numb2,'r'); set(gca,'ytick',persons); set(gca,'xtick',0:30:size(b,1))
    else
        set(gca,'ytick',1:persons); set(gca,'xtick',0:30:size(b,1))
        figure,plot(s.numb,'b'); set(gca,'ytick',1:persons); set(gca,'xtick',0:30:size(b,1))
        figure,plot(s.numb2,'r'); set(gca,'ytick',1:persons); set(gca,'xtick',0:30:size(b,1))
    end        
    if (isequal(t,double(b)))
        msgbox('100 % efficency','Efficency');
    else
        eff = floor(matchFound / size(b,1) *100);
        msgbox(sprintf('%3d %% efficency',eff),'Efficency');
    end