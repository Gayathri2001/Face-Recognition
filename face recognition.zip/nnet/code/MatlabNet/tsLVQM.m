function s = tsLVQM()
    clc
    cd(fileparts(mfilename('fullpath')))
    directory = pwd; 
    cd ../../../;
    thesis = pwd;
    path(strcat(thesis, '\nnet\code\recordKeeping;'), path);
    path(strcat(thesis, '\nnet\code\preprocessing;'), path);
    path(strcat(thesis, '\nnet\code\MatlabNet;'), path);
    selection = input('Records [1]=30+, 2=Simulated Records, 3 = replicated Records :');
    if isempty(selection),        selection = 1;    end
    disp(sprintf('\nValidation or Testing'))
    trainTest = input('1 = Validation, [2] testing:');
    if isempty(trainTest),        trainTest = 2;    end
    if selection == 1 
        load net30+
        if trainTest == 1
            load trainRec35.mat
        else
            load testRec35.mat
        end
        if(exist('net35LVQ.mat','file') == 2)
            load net35LVQ
        end
    elseif selection == 2 
        load netSimulatedRecord
        if trainTest == 1
            load trainRecSimulatedRecord.mat
        else
            load testRecSimulatedRecord.mat
        end
        if(exist('netSRLVQ.mat','file') == 2)
            load netSRLVQ
        end
%         persons = 23;
    elseif selection == 3 
        load netReplicatedRecords
        if trainTest == 1
            load trainReplicatedRecords.mat
        else
            load testReplicatedRecords.mat            
        end
        if(exist('netRRLVQ.mat','file') == 2)
            load netRRLVQ
        end
%         persons = 23;
    end
    persons = 23;
    cd(directory);
    p = p'; 
    a = sim(net,p)';
    percen = ones(1,persons)* 1/persons;
    if (~(exist('netLVQ','var') == 1))
        netLVQ = newlvq(minmax(a),9,percen);
        netLVQ.trainParam.epochs = 30; netLVQ.trainParam.show = 5;
    end
    netLVQ = train(netLVQ,a,t);
    c = input('save the net: [y] ','s');
    if isempty(c),        c = 'y';    end
    if(c == 'y')
        if(selection == 1)
            save('net35LVQ','netLVQ')
        elseif selection == 2
            save('netSRLVQ','netLVQ')
        else
            save('netRRLVQ','netLVQ')
        end
    end
    Y = sim(netLVQ,a);    